<html xmlns:v="urn:schemas-microsoft-com:vml"
      xmlns:o="urn:schemas-microsoft-com:office:office"
      xmlns:w="urn:schemas-microsoft-com:office:word"
      xmlns="http://www.w3.org/TR/REC-html40">

    
    
    <head>
        <meta http-equiv=Content-Type content="text/html; charset=us-ascii">
            <meta name=ProgId content=Word.Document>
                <meta name=Generator content="Microsoft Word 11">
                    <meta name=Originator content="Microsoft Word 11">
                        <link rel=File-List href="B6605DA2_arquivos/filelist.xml">
                            <link rel=Edit-Time-Data href="B6605DA2_arquivos/editdata.mso">
                                <!--[if !mso]>
                                <style>
                                v\:* {behavior:url(#default#VML);}
                                o\:* {behavior:url(#default#VML);}
                                w\:* {behavior:url(#default#VML);}
                                .shape {behavior:url(#default#VML);}
                                </style>
                                <![endif]--><!--[if gte mso 9]><xml>
                                 <o:DocumentProperties>
                                  <o:Author>FATURAMENTO</o:Author>
                                  <o:Template>Normal</o:Template>
                                  <o:LastAuthor>Raio-x</o:LastAuthor>
                                  <o:Revision>55</o:Revision>
                                  <o:TotalTime>323</o:TotalTime>
                                  <o:LastPrinted>2014-01-15T14:24:00Z</o:LastPrinted>
                                  <o:Created>2013-07-30T18:38:00Z</o:Created>
                                  <o:LastSaved>2014-08-08T14:19:00Z</o:LastSaved>
                                  <o:Pages>1</o:Pages>
                                  <o:Words>331</o:Words>
                                  <o:Characters>1789</o:Characters>
                                  <o:Company>CLINICA_RONALDO_BARREIRA</o:Company>
                                  <o:Lines>14</o:Lines>
                                  <o:Paragraphs>4</o:Paragraphs>
                                  <o:CharactersWithSpaces>2116</o:CharactersWithSpaces>
                                  <o:Version>11.9999</o:Version>
                                 </o:DocumentProperties>
                                </xml><![endif]--><!--[if gte mso 9]><xml>
                                 <w:WordDocument>
                                  <w:View>Print</w:View>
                                  <w:Zoom>130</w:Zoom>
                                  <w:HyphenationZone>21</w:HyphenationZone>
                                  <w:PunctuationKerning/>
                                  <w:ValidateAgainstSchemas/>
                                  <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid>
                                  <w:IgnoreMixedContent>false</w:IgnoreMixedContent>
                                  <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText>
                                  <w:Compatibility>
                                   <w:BreakWrappedTables/>
                                   <w:SnapToGridInCell/>
                                   <w:WrapTextWithPunct/>
                                   <w:UseAsianBreakRules/>
                                   <w:DontGrowAutofit/>
                                  </w:Compatibility>
                                  <w:BrowserLevel>MicrosoftInternetExplorer4</w:BrowserLevel>
                                 </w:WordDocument>
                                </xml><![endif]--><!--[if gte mso 9]><xml>
                                 <w:LatentStyles DefLockedState="false" LatentStyleCount="156">
                                  <w:LsdException Locked="true" Name="Normal"/>
                                  <w:LsdException Locked="true" Name="heading 1"/>
                                  <w:LsdException Locked="true" Name="heading 2"/>
                                  <w:LsdException Locked="true" Name="heading 3"/>
                                  <w:LsdException Locked="true" Name="heading 4"/>
                                  <w:LsdException Locked="true" Name="heading 5"/>
                                  <w:LsdException Locked="true" Name="heading 6"/>
                                  <w:LsdException Locked="true" Name="heading 7"/>
                                  <w:LsdException Locked="true" Name="heading 8"/>
                                  <w:LsdException Locked="true" Name="heading 9"/>
                                  <w:LsdException Locked="true" Name="toc 1"/>
                                  <w:LsdException Locked="true" Name="toc 2"/>
                                  <w:LsdException Locked="true" Name="toc 3"/>
                                  <w:LsdException Locked="true" Name="toc 4"/>
                                  <w:LsdException Locked="true" Name="toc 5"/>
                                  <w:LsdException Locked="true" Name="toc 6"/>
                                  <w:LsdException Locked="true" Name="toc 7"/>
                                  <w:LsdException Locked="true" Name="toc 8"/>
                                  <w:LsdException Locked="true" Name="toc 9"/>
                                  <w:LsdException Locked="true" Name="caption"/>
                                  <w:LsdException Locked="true" Name="Title"/>
                                  <w:LsdException Locked="true" Name="Subtitle"/>
                                  <w:LsdException Locked="true" Name="Strong"/>
                                  <w:LsdException Locked="true" Name="Emphasis"/>
                                  <w:LsdException Locked="true" Name="Table Grid"/>
                                 </w:LatentStyles>
                                </xml><![endif]-->
                                <style> 
                                    <!--
                                    /* Font Definitions */
                                    @font-face
                                    {font-family:Wingdings;
                                     panose-1:5 0 0 0 0 0 0 0 0 0;
                                     mso-font-charset:2;
                                     mso-generic-font-family:auto;
                                     mso-font-pitch:variable;
                                     mso-font-signature:0 268435456 0 0 -2147483648 0;}
                                    @font-face
                                    {font-family:Tahoma;
                                     panose-1:2 11 6 4 3 5 4 4 2 4;
                                     mso-font-charset:0;
                                     mso-generic-font-family:swiss;
                                     mso-font-pitch:variable;
                                     mso-font-signature:-520077569 -1073717157 41 0 66047 0;}
                                    @font-face
                                    {font-family:Calibri;
                                     panose-1:2 15 5 2 2 2 4 3 2 4;
                                     mso-font-charset:0;
                                     mso-generic-font-family:swiss;
                                     mso-font-pitch:variable;
                                     mso-font-signature:-536870145 1073786111 1 0 415 0;}
                                    @font-face
                                    {font-family:"Berlin Sans FB";
                                     panose-1:2 14 6 2 2 5 2 2 3 6;
                                     mso-font-charset:0;
                                     mso-generic-font-family:swiss;
                                     mso-font-pitch:variable;
                                     mso-font-signature:3 0 0 0 1 0;}
                                    /* Style Definitions */
                                    p.MsoNormal, li.MsoNormal, div.MsoNormal
                                    {mso-style-parent:"";
                                     margin-top:0cm;
                                     margin-right:0cm;
                                     margin-bottom:10.0pt;
                                     margin-left:0cm;
                                     line-height:115%;
                                     mso-pagination:widow-orphan;
                                     font-size:11.0pt;
                                     font-family:Calibri;
                                     mso-fareast-font-family:"Times New Roman";
                                     mso-bidi-font-family:"Times New Roman";
                                     mso-fareast-language:EN-US;}
                                    p.MsoHeader, li.MsoHeader, div.MsoHeader
                                    {mso-style-noshow:yes;
                                     mso-style-link:"Header Char";
                                     margin:0cm;
                                     margin-bottom:.0001pt;
                                     mso-pagination:widow-orphan;
                                     tab-stops:center 212.6pt right 425.2pt;
                                     font-size:11.0pt;
                                     font-family:Calibri;
                                     mso-fareast-font-family:"Times New Roman";
                                     mso-bidi-font-family:"Times New Roman";
                                     mso-fareast-language:EN-US;}
                                    p.MsoFooter, li.MsoFooter, div.MsoFooter
                                    {mso-style-noshow:yes;
                                     mso-style-link:"Footer Char";
                                     margin:0cm;
                                     margin-bottom:.0001pt;
                                     mso-pagination:widow-orphan;
                                     tab-stops:center 212.6pt right 425.2pt;
                                     font-size:11.0pt;
                                     font-family:Calibri;
                                     mso-fareast-font-family:"Times New Roman";
                                     mso-bidi-font-family:"Times New Roman";
                                     mso-fareast-language:EN-US;}
                                    p.MsoAcetate, li.MsoAcetate, div.MsoAcetate
                                    {mso-style-noshow:yes;
                                     mso-style-link:"Balloon Text Char";
                                     margin:0cm;
                                     margin-bottom:.0001pt;
                                     mso-pagination:widow-orphan;
                                     font-size:8.0pt;
                                     font-family:Tahoma;
                                     mso-fareast-font-family:"Times New Roman";
                                     mso-fareast-language:EN-US;}
                                    span.BalloonTextChar
                                    {mso-style-name:"Balloon Text Char";
                                     mso-style-noshow:yes;
                                     mso-style-locked:yes;
                                     mso-style-link:"Texto de bal\00E3o";
                                     mso-ansi-font-size:8.0pt;
                                     mso-bidi-font-size:8.0pt;
                                     font-family:Tahoma;
                                     mso-ascii-font-family:Tahoma;
                                     mso-hansi-font-family:Tahoma;
                                     mso-bidi-font-family:Tahoma;}
                                    p.ListParagraph, li.ListParagraph, div.ListParagraph
                                    {mso-style-name:"List Paragraph";
                                     margin-top:0cm;
                                     margin-right:0cm;
                                     margin-bottom:10.0pt;
                                     margin-left:36.0pt;
                                     mso-add-space:auto;
                                     line-height:115%;
                                     mso-pagination:widow-orphan;
                                     font-size:11.0pt;
                                     font-family:Calibri;
                                     mso-fareast-font-family:"Times New Roman";
                                     mso-bidi-font-family:"Times New Roman";
                                     mso-fareast-language:EN-US;}
                                    p.ListParagraphCxSpFirst, li.ListParagraphCxSpFirst, div.ListParagraphCxSpFirst
                                    {mso-style-name:"List ParagraphCxSpFirst";
                                     mso-style-type:export-only;
                                     margin-top:0cm;
                                     margin-right:0cm;
                                     margin-bottom:0cm;
                                     margin-left:36.0pt;
                                     margin-bottom:.0001pt;
                                     mso-add-space:auto;
                                     line-height:115%;
                                     mso-pagination:widow-orphan;
                                     font-size:11.0pt;
                                     font-family:Calibri;
                                     mso-fareast-font-family:"Times New Roman";
                                     mso-bidi-font-family:"Times New Roman";
                                     mso-fareast-language:EN-US;}
                                    p.ListParagraphCxSpMiddle, li.ListParagraphCxSpMiddle, div.ListParagraphCxSpMiddle
                                    {mso-style-name:"List ParagraphCxSpMiddle";
                                     mso-style-type:export-only;
                                     margin-top:0cm;
                                     margin-right:0cm;
                                     margin-bottom:0cm;
                                     margin-left:36.0pt;
                                     margin-bottom:.0001pt;
                                     mso-add-space:auto;
                                     line-height:115%;
                                     mso-pagination:widow-orphan;
                                     font-size:11.0pt;
                                     font-family:Calibri;
                                     mso-fareast-font-family:"Times New Roman";
                                     mso-bidi-font-family:"Times New Roman";
                                     mso-fareast-language:EN-US;}
                                    p.ListParagraphCxSpLast, li.ListParagraphCxSpLast, div.ListParagraphCxSpLast
                                    {mso-style-name:"List ParagraphCxSpLast";
                                     mso-style-type:export-only;
                                     margin-top:0cm;
                                     margin-right:0cm;
                                     margin-bottom:10.0pt;
                                     margin-left:36.0pt;
                                     mso-add-space:auto;
                                     line-height:115%;
                                     mso-pagination:widow-orphan;
                                     font-size:11.0pt;
                                     font-family:Calibri;
                                     mso-fareast-font-family:"Times New Roman";
                                     mso-bidi-font-family:"Times New Roman";
                                     mso-fareast-language:EN-US;}
                                    span.HeaderChar
                                    {mso-style-name:"Header Char";
                                     mso-style-noshow:yes;
                                     mso-style-locked:yes;
                                     mso-style-link:Cabe\00E7alho;
                                     font-family:"Times New Roman";
                                     mso-bidi-font-family:"Times New Roman";}
                                    span.FooterChar
                                    {mso-style-name:"Footer Char";
                                     mso-style-noshow:yes;
                                     mso-style-locked:yes;
                                     mso-style-link:Rodap\00E9;
                                     font-family:"Times New Roman";
                                     mso-bidi-font-family:"Times New Roman";}
                                    /* Page Definitions */
                                    @page
                                    {mso-footnote-separator:url("B6605DA2_arquivos/header.htm") fs;
                                     mso-footnote-continuation-separator:url("B6605DA2_arquivos/header.htm") fcs;
                                     mso-endnote-separator:url("B6605DA2_arquivos/header.htm") es;
                                     mso-endnote-continuation-separator:url("B6605DA2_arquivos/header.htm") ecs;}
                                    @page Section1
                                    {size:595.3pt 841.9pt;
                                     margin:1.0cm 2.0cm 1.0cm 42.55pt;
                                     mso-header-margin:35.45pt;
                                     mso-footer-margin:35.45pt;
                                     mso-paper-source:0;}
                                    div.Section1
                                    {page:Section1;}
                                    /* List Definitions */
                                    @list l0
                                    {mso-list-id:265499548;
                                     mso-list-type:hybrid;
                                     mso-list-template-ids:381458850 68550679 68550681 68550683 68550671 68550681 68550683 68550671 68550681 68550683;}
                                    @list l0:level1
                                    {mso-level-number-format:alpha-lower;
                                     mso-level-text:"%1\)";
                                     mso-level-tab-stop:none;
                                     mso-level-number-position:left;
                                     text-indent:-18.0pt;
                                     mso-bidi-font-family:"Times New Roman";}
                                    @list l1
                                    {mso-list-id:948854313;
                                     mso-list-type:hybrid;
                                     mso-list-template-ids:1983138882 732445984 68550659 68550661 68550657 68550659 68550661 68550657 68550659 68550661;}
                                    @list l1:level1
                                    {mso-level-start-at:0;
                                     mso-level-number-format:bullet;
                                     mso-level-text:\F0D8;
                                     mso-level-tab-stop:none;
                                     mso-level-number-position:left;
                                     text-indent:-18.0pt;
                                     font-family:Wingdings;
                                     mso-fareast-font-family:"Times New Roman";}
                                    ol
                                    {margin-bottom:0cm;}
                                    ul
                                    {margin-bottom:0cm;}
                                    -->
                                </style>
                                <!--[if gte mso 10]>
                                <style>
                                 /* Style Definitions */
                                 table.MsoNormalTable
                                        {mso-style-name:"Tabela normal";
                                        mso-tstyle-rowband-size:0;
                                        mso-tstyle-colband-size:0;
                                        mso-style-noshow:yes;
                                        mso-style-parent:"";
                                        mso-padding-alt:0cm 5.4pt 0cm 5.4pt;
                                        mso-para-margin:0cm;
                                        mso-para-margin-bottom:.0001pt;
                                        mso-pagination:widow-orphan;
                                        font-size:10.0pt;
                                        font-family:Calibri;
                                        mso-ansi-language:#0400;
                                        mso-fareast-language:#0400;
                                        mso-bidi-language:#0400;}
                                table.MsoTableGrid
                                        {mso-style-name:"Tabela com grade";
                                        mso-tstyle-rowband-size:0;
                                        mso-tstyle-colband-size:0;
                                        border:solid windowtext 1.0pt;
                                        mso-border-alt:solid windowtext .5pt;
                                        mso-padding-alt:0cm 5.4pt 0cm 5.4pt;
                                        mso-border-insideh:.5pt solid windowtext;
                                        mso-border-insidev:.5pt solid windowtext;
                                        mso-para-margin:0cm;
                                        mso-para-margin-bottom:.0001pt;
                                        mso-pagination:widow-orphan;
                                        font-size:10.0pt;
                                        font-family:Calibri;
                                        mso-fareast-font-family:"Times New Roman";}
                                </style>
                                <![endif]--><!--[if gte mso 9]><xml>
                                 <o:shapedefaults v:ext="edit" spidmax="2050"/>
                                </xml><![endif]--><!--[if gte mso 9]><xml>
                                 <o:shapelayout v:ext="edit">
                                  <o:idmap v:ext="edit" data="1"/>
                                 </o:shapelayout></xml><![endif]-->
                                </head>

                                <body lang=PT-BR style='tab-interval:35.4pt'>

                                    <div class=Section1>

                                        <table class=MsoNormalTable border=1 cellspacing=0 cellpadding=0
                                               style='border-collapse:collapse;mso-table-layout-alt:fixed;border:none;
                                               mso-border-alt:solid windowtext .5pt;mso-yfti-tbllook:160;mso-padding-alt:
                                               0cm 5.4pt 0cm 5.4pt;mso-border-insideh:.5pt solid windowtext;mso-border-insidev:
                                               .5pt solid windowtext'>
                                            <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:42.35pt'>
                                                <td width=697 colspan=53 valign=top style='width:522.8pt;border:solid windowtext 1.0pt;
                                                    border-bottom:none;mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:
                                                    solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:
                                                    0cm 5.4pt 0cm 5.4pt;height:42.35pt'>
                                                    <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                       text-align:center;line-height:normal'><!--[if gte vml 1]><v:shapetype id="_x0000_t75"
                                                        coordsize="21600,21600" o:spt="75" o:preferrelative="t" path="m@4@5l@4@11@9@11@9@5xe"
                                                        filled="f" stroked="f">
                                                        <v:stroke joinstyle="miter"/>
                                                        <v:formulas>
                                                         <v:f eqn="if lineDrawn pixelLineWidth 0"/>
                                                         <v:f eqn="sum @0 1 0"/>
                                                         <v:f eqn="sum 0 0 @1"/>
                                                         <v:f eqn="prod @2 1 2"/>
                                                         <v:f eqn="prod @3 21600 pixelWidth"/>
                                                         <v:f eqn="prod @3 21600 pixelHeight"/>
                                                         <v:f eqn="sum @0 0 1"/>
                                                         <v:f eqn="prod @6 1 2"/>
                                                         <v:f eqn="prod @7 21600 pixelWidth"/>
                                                         <v:f eqn="sum @8 21600 0"/>
                                                         <v:f eqn="prod @7 21600 pixelHeight"/>
                                                         <v:f eqn="sum @10 21600 0"/>
                                                        </v:formulas>
                                                        <v:path o:extrusionok="f" gradientshapeok="t" o:connecttype="rect"/>
                                                        <o:lock v:ext="edit" aspectratio="t"/>
                                                       </v:shapetype><v:shape id="Imagem_x0020_27" o:spid="_x0000_s1026" type="#_x0000_t75"
                                                        alt="cabe&ccedil;alho111" style='position:absolute;left:0;text-align:left;
                                                        margin-left:51.95pt;margin-top:.15pt;width:407pt;height:67.5pt;z-index:-7;
                                                        visibility:visible' wrapcoords="-40 0 -40 21360 21600 21360 21600 0 -40 0">
                                                        <v:imagedata src="B6605DA2_arquivos/image001.jpg" o:title=""/>
                                                        <w:wrap type="tight"/>
                                                       </v:shape><![endif]--><![if !vml]><img width=543 height=90
                                                                                               src="B6605DA2_arquivos/image002.jpg" align=left hspace=12 alt=cabe&ccedil;alho111
                                                                                               v:shapes="Imagem_x0020_27"><![endif]><b style='mso-bidi-font-weight:normal'><span
                                                                    style='font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:Arial'><span
                                                                        style='mso-spacerun:yes'>&nbsp; </span><o:p></o:p></span></b></p>
                                                </td>
                                            </tr>
                                            <tr style='mso-yfti-irow:1;height:42.35pt'>
                                                <td width=697 colspan=53 style='width:522.8pt;border:solid windowtext 1.0pt;
                                                    border-top:none;mso-border-left-alt:solid windowtext .5pt;mso-border-bottom-alt:
                                                    solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:
                                                    #F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;height:42.35pt'>
                                                    <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                       text-align:center;line-height:normal'><b style='mso-bidi-font-weight:normal'><span
                                                                style='font-size:12.0pt;mso-bidi-font-size:10.0pt;font-family:Arial'>FOLHA DE
                                                                LEITURA RADIOL&Oacute;GICA &#8211; CLASSIFICA&Ccedil;&Atilde;O INTERNACIONAL
                                                                DE RADIOGRAFIAS DE PNEUMOCONIOSE &#8211; OIT 2000</span></b><b
                                                            style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;font-family:
                                                                                                  Arial'><o:p></o:p></span></b></p>
                                                </td>
                                            </tr>
                                            <tr style='mso-yfti-irow:2;height:5.65pt;mso-height-rule:exactly'>
                                                <td width=346 colspan=31 valign=top style='width:259.25pt;border:none;
                                                    border-bottom:solid windowtext 1.0pt;mso-border-top-alt:solid windowtext .5pt;
                                                    mso-border-top-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                    padding:0cm 5.4pt 0cm 5.4pt;height:5.65pt;mso-height-rule:exactly'>
                                                    <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                       normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                </td>
                                                <td width=351 colspan=22 valign=top style='width:263.55pt;border:none;
                                                    border-bottom:solid windowtext 1.0pt;mso-border-top-alt:solid windowtext .5pt;
                                                    mso-border-top-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                    padding:0cm 5.4pt 0cm 5.4pt;height:5.65pt;mso-height-rule:exactly'>
                                                    <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                       normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                </td>
                                            </tr>
                                            <tr style='mso-yfti-irow:3;height:31.25pt'>
                                                <td width=54 colspan=3 style='width:40.85pt;border-top:none;border-left:solid windowtext 1.0pt;
                                                    border-bottom:solid windowtext 1.0pt;border-right:none;mso-border-top-alt:
                                                    solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:
                                                    solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;padding:
                                                    0cm 5.4pt 0cm 5.4pt;height:31.25pt'>
                                                    <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                       text-align:center;line-height:normal'><span style='font-size:10.0pt'>NOME: <o:p></o:p></span></p>
                                                </td>
                                                <td width=393 colspan=36 style='width:294.5pt;border-top:none;border-left:
                                                    none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                    mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
                                                    mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
                                                    padding:0cm 5.4pt 0cm 5.4pt;height:31.25pt'>
                                                    <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                       normal'><b style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;
                                                                                                   font-family:Arial;text-transform:uppercase'><o:p><?= @$obj->_nome; ?></o:p></span></b></p>
                                                </td>
                                                <td width=125 colspan=8 valign=top style='width:93.7pt;border:none;
                                                    border-bottom:solid windowtext 1.0pt;mso-border-top-alt:solid windowtext .5pt;
                                                    mso-border-left-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
                                                    mso-border-left-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                    padding:0cm 5.4pt 0cm 5.4pt;height:31.25pt'>
                                                    <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                       normal'><span style='font-size:10.0pt'>DATA DO RX<o:p></o:p></span></p>
                                                </td>
                                                <td width=125 colspan=6 style='width:93.75pt;border-top:none;border-left:
                                                    none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                    mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
                                                    mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
                                                    padding:0cm 5.4pt 0cm 5.4pt;height:31.25pt'>
                                                    <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                       normal'><b style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;
                                                                                                   text-transform:uppercase'><o:p><?php echo substr(@$obj->_data_cadastro, 8, 2) . '/' . substr(@$obj->_data_cadastro, 5, 2) . '/' . substr(@$obj->_data_cadastro, 0, 4); ?></o:p></span></b></p>
                                                </td>
                                            </tr>
                                            <tr style='mso-yfti-irow:4;height:29.65pt'>
                                                <td width=54 colspan=3 style='width:40.85pt;border-top:none;border-left:solid windowtext 1.0pt;
                                                    border-bottom:solid windowtext 1.0pt;border-right:none;mso-border-top-alt:
                                                    solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:
                                                    solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;padding:
                                                    0cm 5.4pt 0cm 5.4pt;height:29.65pt'>
                                                    <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                       normal'><span style='font-size:10.0pt'>N&ordm; RX <o:p></o:p></span></p>
                                                </td>
                                                <td width=151 colspan=12 style='width:113.35pt;border-top:none;border-left:
                                                    none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                    mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
                                                    mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
                                                    padding:0cm 5.4pt 0cm 5.4pt;height:29.65pt'>
                                                    <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                       normal'><b style='mso-bidi-font-weight:normal'><span style='font-size:9.0pt;
                                                                                                   font-family:Arial'><o:p>&nbsp;</o:p></span></b></p>
                                                </td>
                                                <td width=57 colspan=7 style='width:42.6pt;border:none;border-bottom:solid windowtext 1.0pt;
                                                    mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                    mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                    mso-border-bottom-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
                                                    height:29.65pt'>
                                                    <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                       normal'><span style='font-size:10.0pt'>LEITOR<o:p></o:p></span></p>
                                                </td>
                                                <td width=185 colspan=17 style='width:138.55pt;border-top:none;border-left:
                                                    none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                    mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
                                                    mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
                                                    padding:0cm 5.4pt 0cm 5.4pt;height:29.65pt'>
                                                    <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                       normal'><b style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt'>DR
                                                                AFRANIO PEREIRA<o:p></o:p></span></b></p>
                                                </td>
                                                <td width=125 colspan=8 valign=top style='width:93.7pt;border:none;
                                                    border-bottom:solid windowtext 1.0pt;mso-border-top-alt:solid windowtext .5pt;
                                                    mso-border-left-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
                                                    mso-border-left-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                    padding:0cm 5.4pt 0cm 5.4pt;height:29.65pt'>
                                                    <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                       normal'><span style='font-size:10.0pt'>DATA DA LEITURA<o:p></o:p></span></p>
                                                </td>
                                                <td width=125 colspan=6 style='width:93.75pt;border-top:none;border-left:
                                                    none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                    mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
                                                    mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
                                                    padding:0cm 5.4pt 0cm 5.4pt;height:29.65pt'>
                                                    <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                       normal'><b style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;
                                                                                                   text-transform:uppercase'><o:p>&nbsp;</o:p></span></b></p>
                                                </td>
                                            </tr>
                                            <tr style='mso-yfti-irow:5;height:5.65pt;mso-height-rule:exactly'>
                                                <td width=206 colspan=15 valign=top style='width:154.2pt;border:none;
                                                    border-bottom:solid windowtext 1.5pt;mso-border-top-alt:solid windowtext .5pt;
                                                    padding:0cm 5.4pt 0cm 5.4pt;height:5.65pt;mso-height-rule:exactly'>
                                                    <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                       normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                </td>
                                                <td width=140 colspan=16 valign=top style='width:105.05pt;border:none;
                                                    border-bottom:solid windowtext 1.5pt;mso-border-top-alt:solid windowtext .5pt;
                                                    padding:0cm 5.4pt 0cm 5.4pt;height:5.65pt;mso-height-rule:exactly'>
                                                    <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                       normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                </td>
                                                <td width=351 colspan=22 valign=top style='width:263.55pt;border:none;
                                                    border-bottom:solid windowtext 1.5pt;mso-border-top-alt:solid windowtext .5pt;
                                                    padding:0cm 5.4pt 0cm 5.4pt;height:5.65pt;mso-height-rule:exactly'>
                                                    <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                       normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                </td>
                                            </tr>
                                            <tr style='mso-yfti-irow:6;height:6.0pt'>
                                                <td width=35 valign=top style='width:26.3pt;border-top:none;border-left:solid windowtext 1.5pt;
                                                    border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                    mso-border-top-alt:solid windowtext 1.5pt;mso-border-top-alt:1.5pt;
                                                    mso-border-left-alt:1.5pt;mso-border-bottom-alt:.5pt;mso-border-right-alt:
                                                    .5pt;mso-border-color-alt:windowtext;mso-border-style-alt:solid;background:
                                                    #F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;height:6.0pt'>
                                                    <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                       normal'><b style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt'>1A
                                                                <o:p></o:p></span></b></p>
                                                </td>
                                                <td width=151 colspan=12 valign=top style='width:113.55pt;border:none;
                                                    border-right:solid windowtext 1.0pt;mso-border-top-alt:solid windowtext 1.5pt;
                                                    mso-border-left-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext 1.5pt;
                                                    mso-border-left-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
                                                    background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;height:6.0pt'>
                                                    <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                       normal'><span style='font-size:10.0pt'>QUALIDADE T&Eacute;CNICA<o:p></o:p></span></p>
                                                </td>
                                                <td width=19 colspan=2 valign=top style='width:14.35pt;border-top:none;
                                                    border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                    mso-border-top-alt:solid windowtext 1.5pt;mso-border-left-alt:solid windowtext .5pt;
                                                    mso-border-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext 1.5pt;
                                                    background:black;padding:0cm 5.4pt 0cm 5.4pt;height:6.0pt'>
                                                    <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                       normal'><span style='font-size:10.0pt'>1<o:p></o:p></span></p>
                                                </td>
                                                <td width=20 colspan=3 valign=top style='width:14.75pt;border-top:none;
                                                    border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                    mso-border-top-alt:solid windowtext 1.5pt;mso-border-left-alt:solid windowtext .5pt;
                                                    mso-border-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext 1.5pt;
                                                    padding:0cm 5.4pt 0cm 5.4pt;height:6.0pt'>
                                                    <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                       normal'><span style='font-size:10.0pt'>2<o:p></o:p></span></p>
                                                </td>
                                                <td width=19 colspan=2 valign=top style='width:14.3pt;border-top:none;
                                                    border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                    mso-border-top-alt:solid windowtext 1.5pt;mso-border-left-alt:solid windowtext .5pt;
                                                    mso-border-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext 1.5pt;
                                                    padding:0cm 5.4pt 0cm 5.4pt;height:6.0pt'>
                                                    <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                       normal'><span style='font-size:10.0pt'>3<o:p></o:p></span></p>
                                                </td>
                                                <td width=19 colspan=3 valign=top style='width:14.5pt;border-top:none;
                                                    border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                    mso-border-top-alt:solid windowtext 1.5pt;mso-border-left-alt:solid windowtext .5pt;
                                                    mso-border-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext 1.5pt;
                                                    padding:0cm 5.4pt 0cm 5.4pt;height:6.0pt'>
                                                    <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                       normal'><span style='font-size:10.0pt'>4<o:p></o:p></span></p>
                                                </td>
                                                <td width=82 colspan=8 valign=top style='width:61.5pt;border:none;border-right:
                                                    solid windowtext 1.0pt;mso-border-top-alt:solid windowtext 1.5pt;mso-border-left-alt:
                                                    solid windowtext .5pt;mso-border-top-alt:solid windowtext 1.5pt;mso-border-left-alt:
                                                    solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;background:
                                                    #F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;height:6.0pt'>
                                                    <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                       normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                </td>
                                                <td width=32 colspan=2 valign=top style='width:24.25pt;border-top:none;
                                                    border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                    mso-border-top-alt:solid windowtext 1.5pt;mso-border-left-alt:solid windowtext .5pt;
                                                    mso-border-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext 1.5pt;
                                                    background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;height:6.0pt'>
                                                    <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                       normal'><span style='font-size:10.0pt'>1B<o:p></o:p></span></p>
                                                </td>
                                                <td width=319 colspan=20 valign=top style='width:239.3pt;border:none;
                                                    border-right:solid windowtext 1.5pt;mso-border-top-alt:solid windowtext 1.5pt;
                                                    mso-border-left-alt:solid windowtext .5pt;background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;
                                                    height:6.0pt'>
                                                    <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                       normal'><span style='font-size:10.0pt'><span
                                                                style='mso-spacerun:yes'>&nbsp;</span>RADIOGRAFIA NORMAL:<o:p></o:p></span></p>
                                                </td>
                                            </tr>
                                            <tr style='mso-yfti-irow:7;height:24.95pt'>
                                                <td width=346 colspan=31 valign=top style='width:259.25pt;border-top:none;
                                                    border-left:solid windowtext 1.5pt;border-bottom:solid windowtext 1.5pt;
                                                    border-right:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext 1.5pt;
                                                    mso-border-bottom-alt:solid windowtext 1.5pt;mso-border-right-alt:solid windowtext .5pt;
                                                    background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;height:24.95pt'>
                                                    <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                       normal;tab-stops:197.85pt'><span style='font-size:10.0pt'>Coment&aacute;rio:<span
                                                                style='mso-spacerun:yes'>&nbsp; </span><b style='mso-bidi-font-weight:normal'><span
                                                                    style='text-transform:uppercase'><o:p></o:p></span></b></span></p>
                                                    <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                       normal'><b style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></b></p>
                                                </td>
                                                <td width=351 colspan=22 style='width:263.55pt;border-top:none;border-left:
                                                    none;border-bottom:solid windowtext 1.5pt;border-right:solid windowtext 1.5pt;
                                                    mso-border-left-alt:solid windowtext .5pt;background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;
                                                    height:24.95pt'>
                                                    <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                       normal'><!--[if gte vml 1]><v:rect id="_x0000_s1027" style='position:absolute;
                                                        margin-left:-24.05pt;margin-top:.5pt;width:15.5pt;height:14.8pt;z-index:2;
                                                        mso-position-horizontal-relative:text;mso-position-vertical-relative:text'
                                                        wrapcoords="-1029 -1080 -1029 20520 22629 20520 22629 -1080 -1029 -1080">
                                                        <v:textbox style='mso-next-textbox:#_x0000_s1027'>
                                                         <![if !mso]>
                                                         <table cellpadding=0 cellspacing=0 width="100%">
                                                          <tr>
                                                           <td><![endif]>
                                                           <div>
                                                           <p class=MsoNormal><b style='mso-bidi-font-weight:normal'><span
                                                           style='font-size:8.0pt;line-height:115%;font-family:"Berlin Sans FB";
                                                           mso-bidi-font-family:Arial;text-transform:uppercase'>X</span></b><span
                                                           style='mso-bidi-font-size:8.0pt;line-height:115%'><o:p></o:p></span></p>
                                                           <p class=MsoNormal><span style='mso-bidi-font-size:8.0pt;line-height:
                                                           115%'><o:p>&nbsp;</o:p></span></p>
                                                           </div>
                                                           <![if !mso]></td>
                                                          </tr>
                                                         </table>
                                                         <![endif]></v:textbox>
                                                        <w:wrap type="tight"/>
                                                       </v:rect><![endif]--><![if !vml]><img width=27 height=25
                                                                                              src="B6605DA2_arquivos/image003.gif" align=left hspace=12
                                                                                              alt="Caixa de texto: X&#13;&#10;&#13;&#10;" v:shapes="_x0000_s1027"><![endif]><!--[if gte vml 1]><v:rect
                                                                                               id="_x0000_s1028" style='position:absolute;margin-left:116.15pt;
                                                                                               margin-top:.5pt;width:15.5pt;height:14.8pt;z-index:3;
                                                                                               mso-position-horizontal-relative:text;mso-position-vertical-relative:text'
                                                                                               wrapcoords="-1029 -1080 -1029 20520 22629 20520 22629 -1080 -1029 -1080">
                                                                                               <v:textbox style='mso-next-textbox:#_x0000_s1028'>
                                                                                                <![if !mso]>
                                                                                                <table cellpadding=0 cellspacing=0 width="100%">
                                                                                                 <tr>
                                                                                                  <td><![endif]>
                                                                                                  <div>
                                                                                                  <p class=MsoNormal><b style='mso-bidi-font-weight:normal'><span
                                                                                                  style='font-size:8.0pt;line-height:115%;font-family:"Berlin Sans FB";
                                                                                                  mso-bidi-font-family:Arial;text-transform:uppercase'><o:p>&nbsp;</o:p></span></b></p>
                                                                                                  <p class=MsoNormal><b style='mso-bidi-font-weight:normal'><span
                                                                                                  style='font-size:8.0pt;line-height:115%;font-family:Arial;text-transform:
                                                                                                  uppercase'><o:p>&nbsp;</o:p></span></b></p>
                                                                                                  </div>
                                                                                                  <![if !mso]></td>
                                                                                                 </tr>
                                                                                                </table>
                                                                                                <![endif]></v:textbox>
                                                                                               <w:wrap type="tight"/>
                                                                                              </v:rect><![endif]--><![if !vml]><img width=27 height=25
                                                                                                  src="B6605DA2_arquivos/image004.gif" align=left hspace=12
                                                                                                  alt="Caixa de texto: " v:shapes="_x0000_s1028"><![endif]><span
                                                                    style='font-size:8.0pt;mso-bidi-font-size:10.0pt'><span
                                                                        style='mso-spacerun:yes'>&nbsp; </span>SIM (finalizar a leitura)<span
                                                                        style='mso-spacerun:yes'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                                    </span>N&Atilde;O (passe p/a se&ccedil;&atilde;o 2)</span><span
                                                                    style='font-size:10.0pt'><o:p></o:p></span></p>
                                                                </td>
                                                                </tr>
                                                                <tr style='mso-yfti-irow:8;height:5.65pt;mso-height-rule:exactly'>
                                                                    <td width=697 colspan=53 valign=top style='width:522.8pt;border:none;
                                                                        border-bottom:solid windowtext 1.5pt;mso-border-top-alt:solid windowtext 1.5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:5.65pt;mso-height-rule:exactly'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                </tr>
                                                                <tr style='mso-yfti-irow:9;height:9.5pt'>
                                                                    <td width=35 valign=top style='width:26.3pt;border-top:none;border-left:solid windowtext 1.5pt;
                                                                        border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-top-alt:solid windowtext 1.5pt;mso-border-top-alt:1.5pt;
                                                                        mso-border-left-alt:1.5pt;mso-border-bottom-alt:.5pt;mso-border-right-alt:
                                                                        .5pt;mso-border-color-alt:windowtext;mso-border-style-alt:solid;background:
                                                                        #F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;height:9.5pt'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><b style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt'>2A<o:p></o:p></span></b></p>
                                                                    </td>
                                                                    <td width=266 colspan=26 rowspan=2 style='width:199.25pt;border:none;
                                                                        border-bottom:solid windowtext 1.0pt;mso-border-top-alt:solid windowtext 1.5pt;
                                                                        mso-border-left-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext 1.5pt;
                                                                        mso-border-left-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                        background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;height:9.5pt'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><!--[if gte vml 1]><v:rect id="_x0000_s1029" style='position:absolute;
                                                                            margin-left:178.1pt;margin-top:2.85pt;width:15.5pt;height:14.8pt;z-index:5;
                                                                            mso-position-horizontal-relative:text;mso-position-vertical-relative:text'
                                                                            wrapcoords="-1029 -1080 -1029 20520 22629 20520 22629 -1080 -1029 -1080">
                                                                            <v:textbox style='mso-next-textbox:#_x0000_s1029'>
                                                                             <![if !mso]>
                                                                             <table cellpadding=0 cellspacing=0 width="100%">
                                                                              <tr>
                                                                               <td><![endif]>
                                                                               <div>
                                                                               <p class=MsoNormal><b style='mso-bidi-font-weight:normal'><span
                                                                               style='font-size:8.0pt;line-height:115%;font-family:Arial;text-transform:
                                                                               uppercase'><o:p>&nbsp;</o:p></span></b></p>
                                                                               </div>
                                                                               <![if !mso]></td>
                                                                              </tr>
                                                                             </table>
                                                                             <![endif]></v:textbox>
                                                                            <w:wrap type="tight"/>
                                                                           </v:rect><![endif]--><![if !vml]><img width=27 height=26
                                                                                                                  src="B6605DA2_arquivos/image005.gif" align=left hspace=12 v:shapes="_x0000_s1029"><![endif]><span
                                                                                    style='font-size:9.0pt'>ALGUMA ANORMALIDADE DE PARENQUIMA CONSISTENTE COM
                                                                                    PNEUMOCONIOSE:<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=174 colspan=14 rowspan=2 style='width:130.4pt;border:none;
                                                                        border-bottom:solid windowtext 1.0pt;mso-border-top-alt:solid windowtext 1.5pt;
                                                                        mso-border-top-alt:solid windowtext 1.5pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                        background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;height:9.5pt'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><span style='font-size:10.0pt'>SIM (complete 2B e 2C)<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=222 colspan=12 rowspan=2 style='width:166.85pt;border-top:none;
                                                                        border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.5pt;
                                                                        mso-border-top-alt:solid windowtext 1.5pt;mso-border-top-alt:solid windowtext 1.5pt;
                                                                        mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext 1.5pt;
                                                                        background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;height:9.5pt'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><!--[if gte vml 1]><v:rect id="_x0000_s1030" style='position:absolute;
                                                                            margin-left:-89.3pt;margin-top:-14.25pt;width:15.5pt;height:14.8pt;
                                                                            z-index:4;mso-position-horizontal-relative:text;
                                                                            mso-position-vertical-relative:text' wrapcoords="-1029 -1080 -1029 20520 22629 20520 22629 -1080 -1029 -1080">
                                                                            <v:textbox style='mso-next-textbox:#_x0000_s1030'>
                                                                             <![if !mso]>
                                                                             <table cellpadding=0 cellspacing=0 width="100%">
                                                                              <tr>
                                                                               <td><![endif]>
                                                                               <div>
                                                                               <p class=MsoNormal><span style='mso-bidi-font-size:8.0pt;line-height:
                                                                               115%'><o:p>&nbsp;</o:p></span></p>
                                                                               <p class=MsoNormal><b style='mso-bidi-font-weight:normal'><span
                                                                               style='font-size:8.0pt;line-height:115%;font-family:"Berlin Sans FB";
                                                                               mso-bidi-font-family:Arial;text-transform:uppercase'><o:p>&nbsp;</o:p></span></b></p>
                                                                               <p class=MsoNormal><b style='mso-bidi-font-weight:normal'><span
                                                                               style='font-size:8.0pt;line-height:115%;font-family:"Berlin Sans FB";
                                                                               mso-bidi-font-family:Arial;text-transform:uppercase'><o:p>&nbsp;</o:p></span></b></p>
                                                                               <p class=MsoNormal><b style='mso-bidi-font-weight:normal'><span
                                                                               style='font-size:8.0pt;line-height:115%;font-family:Arial;text-transform:
                                                                               uppercase'><o:p>&nbsp;</o:p></span></b></p>
                                                                               </div>
                                                                               <![if !mso]></td>
                                                                              </tr>
                                                                             </table>
                                                                             <![endif]></v:textbox>
                                                                            <w:wrap type="tight"/>
                                                                           </v:rect><![endif]--><![if !vml]><img width=27 height=26
                                                                                                                  src="B6605DA2_arquivos/image006.gif" align=left hspace=12
                                                                                                                  alt="Caixa de texto: " v:shapes="_x0000_s1030"><![endif]><span
                                                                                    style='font-size:10.0pt'>N&Atilde;O (Passe para a se&ccedil;&atilde;o 3)<o:p></o:p></span></p>
                                                                    </td>
                                                                </tr>
                                                                <tr style='mso-yfti-irow:10;height:9.5pt'>
                                                                    <td width=35 valign=top style='width:26.3pt;border-top:none;border-left:solid windowtext 1.5pt;
                                                                        border-bottom:solid windowtext 1.0pt;border-right:none;mso-border-top-alt:
                                                                        solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:
                                                                        solid windowtext 1.5pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                        background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;height:9.5pt'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                </tr>
                                                                <tr style='mso-yfti-irow:11'>
                                                                    <td width=35 valign=top style='width:26.3pt;border-top:none;border-left:solid windowtext 1.5pt;
                                                                        border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                        mso-border-left-alt:solid windowtext 1.5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><span style='font-size:10.0pt'>2B<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=392 colspan=36 valign=top style='width:294.35pt;border:none;
                                                                        mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><span style='font-size:10.0pt'>PEQUENAS OPCIADES<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=30 colspan=3 rowspan=2 valign=top style='width:22.35pt;border:none;
                                                                        border-right:solid windowtext 1.0pt;mso-border-top-alt:solid windowtext .5pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=29 colspan=2 valign=top style='width:21.55pt;border-top:none;
                                                                        border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><span style='font-size:10.0pt'>2C<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=211 colspan=11 valign=top style='width:158.25pt;border:none;
                                                                        border-right:solid windowtext 1.5pt;mso-border-top-alt:solid windowtext .5pt;
                                                                        mso-border-left-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><span style='font-size:10.0pt'>GRANDES OPACIDADES<o:p></o:p></span></p>
                                                                    </td>
                                                                </tr>
                                                                <tr style='mso-yfti-irow:12;height:6.0pt'>
                                                                    <td width=166 colspan=10 valign=top style='width:124.5pt;border:none;
                                                                        border-left:solid windowtext 1.5pt;padding:0cm 5.4pt 0cm 5.4pt;height:6.0pt'>
                                                                        <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           text-align:center;line-height:normal'><span style='font-size:10.0pt'>a) Forma
                                                                                / tamanho<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=16 colspan=2 rowspan=5 valign=top style='width:11.95pt;border:none;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:6.0pt'>
                                                                        <p class=ListParagraphCxSpFirst style='margin:0cm;margin-bottom:.0001pt;
                                                                           mso-add-space:auto;line-height:normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=82 colspan=11 valign=top style='width:61.3pt;border:none;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:6.0pt'>
                                                                        <p class=ListParagraphCxSpMiddle align=center style='margin:0cm;margin-bottom:
                                                                           .0001pt;mso-add-space:auto;text-align:center;line-height:normal'><span
                                                                                style='font-size:10.0pt'>b) Zonas<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=19 colspan=2 rowspan=5 valign=top style='width:14.35pt;border:none;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:6.0pt'>
                                                                        <p class=ListParagraphCxSpMiddle style='margin:0cm;margin-bottom:.0001pt;
                                                                           mso-add-space:auto;line-height:normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=145 colspan=12 valign=top style='width:108.55pt;border:none;
                                                                        border-bottom:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:6.0pt'>
                                                                        <p class=ListParagraphCxSpMiddle align=center style='margin-top:0cm;
                                                                           margin-right:0cm;margin-bottom:0cm;margin-left:-2.45pt;margin-bottom:.0001pt;
                                                                           mso-add-space:auto;text-align:center;line-height:normal'><span
                                                                                style='font-size:10.0pt'>c) Profus&atilde;o<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=240 colspan=13 valign=top style='width:179.8pt;border:none;
                                                                        border-right:solid windowtext 1.5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:6.0pt'>
                                                                        <p class=ListParagraphCxSpLast align=center style='margin-top:0cm;margin-right:
                                                                           0cm;margin-bottom:0cm;margin-left:-2.45pt;margin-bottom:.0001pt;mso-add-space:
                                                                           auto;text-align:center;line-height:normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                </tr>
                                                                <tr style='mso-yfti-irow:13;height:4.0pt'>
                                                                    <td width=72 colspan=4 style='width:54.3pt;border-top:none;border-left:solid windowtext 1.5pt;
                                                                        border-bottom:solid windowtext 1.0pt;border-right:none;mso-border-left-alt:
                                                                        solid windowtext 1.5pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=ListParagraphCxSpFirst align=center style='margin-top:0cm;
                                                                           margin-right:0cm;margin-bottom:0cm;margin-left:-7.1pt;margin-bottom:.0001pt;
                                                                           mso-add-space:auto;text-align:center;line-height:normal'><span
                                                                                style='font-size:8.0pt'>Prim&aacute;ria<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=19 colspan=2 rowspan=4 style='width:14.2pt;border:none;padding:
                                                                        0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=ListParagraphCxSpMiddle align=center style='margin-top:0cm;
                                                                           margin-right:0cm;margin-bottom:0cm;margin-left:-7.1pt;margin-bottom:.0001pt;
                                                                           mso-add-space:auto;text-align:center;line-height:normal'><span
                                                                                style='font-size:8.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=75 colspan=4 style='width:56.0pt;border:none;border-bottom:solid windowtext 1.0pt;
                                                                        mso-border-bottom-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
                                                                        height:4.0pt'>
                                                                        <p class=ListParagraphCxSpMiddle align=center style='margin-top:0cm;
                                                                           margin-right:0cm;margin-bottom:0cm;margin-left:-7.1pt;margin-bottom:.0001pt;
                                                                           mso-add-space:auto;text-align:center;line-height:normal'><span
                                                                                style='font-size:8.0pt'>Secund&aacute;ria<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=41 colspan=5 valign=top style='width:30.45pt;border:none;
                                                                        border-bottom:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           text-align:center;line-height:normal'><span style='font-size:10.0pt'>D<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=41 colspan=6 valign=top style='width:30.85pt;border:none;
                                                                        border-bottom:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           text-align:center;line-height:normal'><span style='font-size:10.0pt'>E<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=48 colspan=5 style='width:35.8pt;border:solid windowtext 1.0pt;
                                                                        border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
                                                                           margin-bottom:0cm;margin-left:1.7pt;margin-bottom:.0001pt;text-align:center;
                                                                           line-height:normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt'>0/-<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=49 colspan=4 style='width:36.4pt;border:solid windowtext 1.0pt;
                                                                        border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                        solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           text-align:center;line-height:normal'><span style='font-size:8.0pt;
                                                                                mso-bidi-font-size:10.0pt'>0/0<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=48 colspan=3 style='width:36.35pt;border:solid windowtext 1.0pt;
                                                                        border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                        solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           text-align:center;line-height:normal'><span style='font-size:8.0pt;
                                                                                mso-bidi-font-size:10.0pt'>0/1<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=30 colspan=3 valign=top style='width:22.35pt;border:none;
                                                                        border-right:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        mso-border-left-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
                                                                           margin-left:18.0pt;margin-bottom:.0001pt;line-height:normal'><span
                                                                                style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=240 colspan=13 valign=top style='width:179.8pt;border:none;
                                                                        border-right:solid windowtext 1.5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
                                                                           margin-left:18.0pt;margin-bottom:.0001pt;line-height:normal'><span
                                                                                style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                </tr>
                                                                <tr style='mso-yfti-irow:14;height:4.3pt'>
                                                                    <td width=36 colspan=2 style='width:26.9pt;border-top:none;border-left:solid windowtext 1.5pt;
                                                                        border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                        mso-border-left-alt:solid windowtext 1.5pt;padding:0cm 5.4pt 0cm 5.4pt;
                                                                        height:4.3pt'>
                                                                        <p class=ListParagraphCxSpFirst align=center style='margin:0cm;margin-bottom:
                                                                           .0001pt;mso-add-space:auto;text-align:center;line-height:normal'><span
                                                                                style='font-size:10.0pt'>p<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=37 colspan=2 style='width:27.4pt;border-top:none;border-left:none;
                                                                        border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:4.3pt'>
                                                                        <p class=ListParagraphCxSpMiddle align=center style='margin:0cm;margin-bottom:
                                                                           .0001pt;mso-add-space:auto;text-align:center;line-height:normal'><span
                                                                                style='font-size:10.0pt'>s<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=37 colspan=2 style='width:28.0pt;border:solid windowtext 1.0pt;
                                                                        border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:4.3pt'>
                                                                        <p class=ListParagraphCxSpMiddle align=center style='margin:0cm;margin-bottom:
                                                                           .0001pt;mso-add-space:auto;text-align:center;line-height:normal'><span
                                                                                style='font-size:10.0pt'>p<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=37 colspan=2 style='width:28.0pt;border:solid windowtext 1.0pt;
                                                                        border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                        solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:4.3pt'>
                                                                        <p class=ListParagraphCxSpMiddle align=center style='margin:0cm;margin-bottom:
                                                                           .0001pt;mso-add-space:auto;text-align:center;line-height:normal'><span
                                                                                style='font-size:10.0pt'>s<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=41 colspan=5 valign=top style='width:30.45pt;border:solid windowtext 1.0pt;
                                                                        border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:4.3pt'>
                                                                        <p class=ListParagraphCxSpMiddle style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           mso-add-space:auto;line-height:normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=41 colspan=6 valign=top style='width:30.85pt;border-top:none;
                                                                        border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:4.3pt'>
                                                                        <p class=ListParagraphCxSpMiddle style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           mso-add-space:auto;line-height:normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=48 colspan=5 style='width:35.8pt;border:solid windowtext 1.0pt;
                                                                        border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:4.3pt'>
                                                                        <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
                                                                           margin-bottom:0cm;margin-left:1.7pt;margin-bottom:.0001pt;text-align:center;
                                                                           line-height:normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt'>1/0<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=49 colspan=4 style='width:36.4pt;border-top:none;border-left:none;
                                                                        border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:4.3pt'>
                                                                        <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
                                                                           margin-bottom:0cm;margin-left:1.75pt;margin-bottom:.0001pt;text-align:center;
                                                                           line-height:normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt'>1/1<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=48 colspan=3 style='width:36.35pt;border-top:none;border-left:none;
                                                                        border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:4.3pt'>
                                                                        <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
                                                                           margin-bottom:0cm;margin-left:1.7pt;margin-bottom:.0001pt;text-align:center;
                                                                           line-height:normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt'>1/2<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=30 colspan=3 valign=top style='width:22.35pt;border:none;
                                                                        border-right:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        mso-border-left-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:4.3pt'>
                                                                        <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
                                                                           margin-left:18.0pt;margin-bottom:.0001pt;line-height:normal'><span
                                                                                style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=39 colspan=4 style='width:28.9pt;border:none;border-right:solid windowtext 1.0pt;
                                                                        mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
                                                                        height:4.3pt'>
                                                                        <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
                                                                           margin-bottom:0cm;margin-left:.55pt;margin-bottom:.0001pt;text-align:center;
                                                                           line-height:normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=43 colspan=2 style='width:32.3pt;border:solid windowtext 1.0pt;
                                                                        border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                        solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:4.3pt'>
                                                                        <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
                                                                           margin-bottom:0cm;margin-left:.55pt;margin-bottom:.0001pt;text-align:center;
                                                                           line-height:normal'><span style='font-size:10.0pt'>0<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=43 colspan=3 style='width:32.4pt;border:solid windowtext 1.0pt;
                                                                        border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                        solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:4.3pt'>
                                                                        <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           text-align:center;line-height:normal'><span style='font-size:10.0pt'>A<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=43 colspan=2 style='width:32.3pt;border:solid windowtext 1.0pt;
                                                                        border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                        solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:4.3pt'>
                                                                        <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           text-align:center;line-height:normal'><span style='font-size:10.0pt'>B<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=43 style='width:32.35pt;border:solid windowtext 1.0pt;border-left:
                                                                        none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:4.3pt'>
                                                                        <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           text-align:center;line-height:normal'><span style='font-size:10.0pt'>C<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=29 valign=top style='width:21.55pt;border:none;border-right:solid windowtext 1.5pt;
                                                                        mso-border-left-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
                                                                        height:4.3pt'>
                                                                        <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
                                                                           margin-left:18.0pt;margin-bottom:.0001pt;line-height:normal'><span
                                                                                style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                </tr>
                                                                <tr style='mso-yfti-irow:15;height:4.0pt'>
                                                                    <td width=36 colspan=2 style='width:26.9pt;border-top:none;border-left:solid windowtext 1.5pt;
                                                                        border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                        mso-border-left-alt:solid windowtext 1.5pt;padding:0cm 5.4pt 0cm 5.4pt;
                                                                        height:4.0pt'>
                                                                        <p class=ListParagraphCxSpFirst align=center style='margin:0cm;margin-bottom:
                                                                           .0001pt;mso-add-space:auto;text-align:center;line-height:normal'><span
                                                                                style='font-size:10.0pt'>q<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=37 colspan=2 style='width:27.4pt;border-top:none;border-left:none;
                                                                        border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=ListParagraphCxSpMiddle align=center style='margin:0cm;margin-bottom:
                                                                           .0001pt;mso-add-space:auto;text-align:center;line-height:normal'><span
                                                                                style='font-size:10.0pt'>t<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=37 colspan=2 style='width:28.0pt;border:solid windowtext 1.0pt;
                                                                        border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=ListParagraphCxSpMiddle align=center style='margin:0cm;margin-bottom:
                                                                           .0001pt;mso-add-space:auto;text-align:center;line-height:normal'><span
                                                                                style='font-size:10.0pt'>q<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=37 colspan=2 style='width:28.0pt;border-top:none;border-left:none;
                                                                        border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=ListParagraphCxSpMiddle align=center style='margin:0cm;margin-bottom:
                                                                           .0001pt;mso-add-space:auto;text-align:center;line-height:normal'><span
                                                                                style='font-size:10.0pt'>t<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=41 colspan=5 valign=top style='width:30.45pt;border:solid windowtext 1.0pt;
                                                                        border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=ListParagraphCxSpMiddle style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           mso-add-space:auto;line-height:normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=41 colspan=6 valign=top style='width:30.85pt;border-top:none;
                                                                        border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=ListParagraphCxSpMiddle style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           mso-add-space:auto;line-height:normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=48 colspan=5 style='width:35.8pt;border:solid windowtext 1.0pt;
                                                                        border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           text-align:center;line-height:normal'><span style='font-size:8.0pt;
                                                                                mso-bidi-font-size:10.0pt'>2/1<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=49 colspan=4 style='width:36.4pt;border-top:none;border-left:none;
                                                                        border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           text-align:center;line-height:normal'><span style='font-size:8.0pt;
                                                                                mso-bidi-font-size:10.0pt'>2/2<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=48 colspan=3 style='width:36.35pt;border-top:none;border-left:none;
                                                                        border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           text-align:center;line-height:normal'><span style='font-size:8.0pt;
                                                                                mso-bidi-font-size:10.0pt'>2/3<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=30 colspan=3 valign=top style='width:22.35pt;border:none;
                                                                        border-right:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        mso-border-left-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
                                                                           margin-left:18.0pt;margin-bottom:.0001pt;line-height:normal'><span
                                                                                style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=240 colspan=13 valign=top style='width:179.8pt;border:none;
                                                                        border-right:solid windowtext 1.5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
                                                                           margin-left:18.0pt;margin-bottom:.0001pt;line-height:normal'><span
                                                                                style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                </tr>
                                                                <tr style='mso-yfti-irow:16;height:4.0pt'>
                                                                    <td width=36 colspan=2 style='width:26.9pt;border-top:none;border-left:solid windowtext 1.5pt;
                                                                        border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                        mso-border-left-alt:solid windowtext 1.5pt;padding:0cm 5.4pt 0cm 5.4pt;
                                                                        height:4.0pt'>
                                                                        <p class=ListParagraphCxSpFirst align=center style='margin:0cm;margin-bottom:
                                                                           .0001pt;mso-add-space:auto;text-align:center;line-height:normal'><span
                                                                                style='font-size:10.0pt'>r<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=37 colspan=2 style='width:27.4pt;border-top:none;border-left:none;
                                                                        border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=ListParagraphCxSpMiddle align=center style='margin:0cm;margin-bottom:
                                                                           .0001pt;mso-add-space:auto;text-align:center;line-height:normal'><span
                                                                                style='font-size:10.0pt'>u<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=37 colspan=2 style='width:28.0pt;border:solid windowtext 1.0pt;
                                                                        border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=ListParagraphCxSpMiddle align=center style='margin:0cm;margin-bottom:
                                                                           .0001pt;mso-add-space:auto;text-align:center;line-height:normal'><span
                                                                                style='font-size:10.0pt'>r<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=37 colspan=2 style='width:28.0pt;border-top:none;border-left:none;
                                                                        border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=ListParagraphCxSpMiddle align=center style='margin:0cm;margin-bottom:
                                                                           .0001pt;mso-add-space:auto;text-align:center;line-height:normal'><span
                                                                                style='font-size:10.0pt'>u<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=41 colspan=5 valign=top style='width:30.45pt;border:solid windowtext 1.0pt;
                                                                        border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=ListParagraphCxSpMiddle style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           mso-add-space:auto;line-height:normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=41 colspan=6 valign=top style='width:30.85pt;border-top:none;
                                                                        border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=ListParagraphCxSpMiddle style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           mso-add-space:auto;line-height:normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=48 colspan=5 style='width:35.8pt;border:solid windowtext 1.0pt;
                                                                        border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           text-align:center;line-height:normal'><span style='font-size:8.0pt;
                                                                                mso-bidi-font-size:10.0pt'>3/2<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=49 colspan=4 style='width:36.4pt;border-top:none;border-left:none;
                                                                        border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
                                                                           margin-bottom:0cm;margin-left:1.75pt;margin-bottom:.0001pt;text-align:center;
                                                                           line-height:normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt'>3/3<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=48 colspan=3 style='width:36.35pt;border-top:none;border-left:none;
                                                                        border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
                                                                           margin-bottom:0cm;margin-left:1.7pt;margin-bottom:.0001pt;text-align:center;
                                                                           line-height:normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt'>3/4<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=30 colspan=3 valign=top style='width:22.35pt;border:none;
                                                                        border-right:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        mso-border-left-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
                                                                           margin-left:18.0pt;margin-bottom:.0001pt;line-height:normal'><span
                                                                                style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=240 colspan=13 valign=top style='width:179.8pt;border:none;
                                                                        border-right:solid windowtext 1.5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:4.0pt'>
                                                                        <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
                                                                           margin-left:18.0pt;margin-bottom:.0001pt;line-height:normal'><span
                                                                                style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                </tr>
                                                                <tr style='mso-yfti-irow:17;height:5.65pt;mso-height-rule:exactly'>
                                                                    <td width=36 colspan=2 style='width:26.9pt;border-top:none;border-left:solid windowtext 1.5pt;
                                                                        border-bottom:solid windowtext 1.5pt;border-right:none;mso-border-top-alt:
                                                                        solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:5.65pt;mso-height-rule:
                                                                        exactly'>
                                                                        <p class=ListParagraphCxSpFirst align=center style='margin:0cm;margin-bottom:
                                                                           .0001pt;mso-add-space:auto;text-align:center;line-height:normal'><span
                                                                                style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=37 colspan=2 style='width:27.4pt;border:none;border-bottom:solid windowtext 1.5pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
                                                                        height:5.65pt;mso-height-rule:exactly'>
                                                                        <p class=ListParagraphCxSpMiddle align=center style='margin:0cm;margin-bottom:
                                                                           .0001pt;mso-add-space:auto;text-align:center;line-height:normal'><span
                                                                                style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=19 colspan=2 style='width:14.2pt;border:none;border-bottom:solid windowtext 1.5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:5.65pt;mso-height-rule:exactly'>
                                                                        <p class=ListParagraphCxSpMiddle align=center style='margin:0cm;margin-bottom:
                                                                           .0001pt;mso-add-space:auto;text-align:center;line-height:normal'><span
                                                                                style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=37 colspan=2 style='width:28.0pt;border:none;border-bottom:solid windowtext 1.5pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
                                                                        height:5.65pt;mso-height-rule:exactly'>
                                                                        <p class=ListParagraphCxSpMiddle align=center style='margin:0cm;margin-bottom:
                                                                           .0001pt;mso-add-space:auto;text-align:center;line-height:normal'><span
                                                                                style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=37 colspan=2 style='width:28.0pt;border:none;border-bottom:solid windowtext 1.5pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
                                                                        height:5.65pt;mso-height-rule:exactly'>
                                                                        <p class=ListParagraphCxSpMiddle align=center style='margin:0cm;margin-bottom:
                                                                           .0001pt;mso-add-space:auto;text-align:center;line-height:normal'><span
                                                                                style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=16 colspan=2 valign=top style='width:11.95pt;border:none;
                                                                        border-bottom:solid windowtext 1.5pt;padding:0cm 5.4pt 0cm 5.4pt;height:5.65pt;
                                                                        mso-height-rule:exactly'>
                                                                        <p class=ListParagraphCxSpMiddle style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           mso-add-space:auto;line-height:normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=41 colspan=5 valign=top style='width:30.45pt;border:none;
                                                                        border-bottom:solid windowtext 1.5pt;mso-border-top-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:5.65pt;mso-height-rule:exactly'>
                                                                        <p class=ListParagraphCxSpMiddle style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           mso-add-space:auto;line-height:normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=41 colspan=6 valign=top style='width:30.85pt;border:none;
                                                                        border-bottom:solid windowtext 1.5pt;mso-border-top-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:5.65pt;mso-height-rule:exactly'>
                                                                        <p class=ListParagraphCxSpMiddle style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           mso-add-space:auto;line-height:normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=19 colspan=2 valign=top style='width:14.35pt;border:none;
                                                                        border-bottom:solid windowtext 1.5pt;padding:0cm 5.4pt 0cm 5.4pt;height:5.65pt;
                                                                        mso-height-rule:exactly'>
                                                                        <p class=ListParagraphCxSpLast style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           mso-add-space:auto;line-height:normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=48 colspan=5 style='width:35.8pt;border:none;border-bottom:solid windowtext 1.5pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
                                                                        height:5.65pt;mso-height-rule:exactly'>
                                                                        <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           text-align:center;line-height:normal'><span style='font-size:8.0pt;
                                                                                mso-bidi-font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=49 colspan=4 style='width:36.4pt;border:none;border-bottom:solid windowtext 1.5pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
                                                                        height:5.65pt;mso-height-rule:exactly'>
                                                                        <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
                                                                           margin-bottom:0cm;margin-left:1.75pt;margin-bottom:.0001pt;text-align:center;
                                                                           line-height:normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=48 colspan=3 style='width:36.35pt;border:none;border-bottom:solid windowtext 1.5pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
                                                                        height:5.65pt;mso-height-rule:exactly'>
                                                                        <p class=MsoNormal align=center style='margin-top:0cm;margin-right:0cm;
                                                                           margin-bottom:0cm;margin-left:1.7pt;margin-bottom:.0001pt;text-align:center;
                                                                           line-height:normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=30 colspan=3 valign=top style='width:22.35pt;border-top:none;
                                                                        border-left:none;border-bottom:solid windowtext 1.5pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-bottom-alt:solid windowtext 1.5pt;mso-border-right-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:5.65pt;mso-height-rule:exactly'>
                                                                        <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
                                                                           margin-left:18.0pt;margin-bottom:.0001pt;line-height:normal'><span
                                                                                style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=240 colspan=13 valign=top style='width:179.8pt;border-top:none;
                                                                        border-left:none;border-bottom:solid windowtext 1.5pt;border-right:solid windowtext 1.5pt;
                                                                        mso-border-left-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
                                                                        height:5.65pt;mso-height-rule:exactly'>
                                                                        <p class=MsoNormal style='margin-top:0cm;margin-right:0cm;margin-bottom:0cm;
                                                                           margin-left:18.0pt;margin-bottom:.0001pt;line-height:normal'><span
                                                                                style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                </tr>
                                                                <tr style='mso-yfti-irow:18;height:5.65pt;mso-height-rule:exactly'>
                                                                    <td width=697 colspan=53 valign=top style='width:522.8pt;border:none;
                                                                        border-bottom:solid windowtext 1.5pt;mso-border-top-alt:solid windowtext 1.5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:5.65pt;mso-height-rule:exactly'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                </tr>
                                                                <tr style='mso-yfti-irow:19;height:11.5pt'>
                                                                    <td width=35 valign=top style='width:26.3pt;border-top:none;border-left:solid windowtext 1.5pt;
                                                                        border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-top-alt:solid windowtext 1.5pt;mso-border-top-alt:1.5pt;
                                                                        mso-border-left-alt:1.5pt;mso-border-bottom-alt:.5pt;mso-border-right-alt:
                                                                        .5pt;mso-border-color-alt:windowtext;mso-border-style-alt:solid;background:
                                                                        #F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;height:11.5pt'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><b style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt'>3A<o:p></o:p></span></b></p>
                                                                    </td>
                                                                    <td width=237 colspan=23 rowspan=2 style='width:177.85pt;border:none;
                                                                        border-bottom:solid windowtext 1.0pt;mso-border-top-alt:solid windowtext 1.5pt;
                                                                        mso-border-left-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext 1.5pt;
                                                                        mso-border-left-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                        background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;height:11.5pt'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><span style='font-size:10.0pt'>ALGUMA ANORMALIDADE PLEURAL<o:p></o:p></span></p>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><span style='font-size:10.0pt'>CONSISTENTE COM PNEUMOCONIOSE:<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=202 colspan=17 rowspan=2 style='width:151.8pt;border:none;
                                                                        border-bottom:solid windowtext 1.0pt;mso-border-top-alt:solid windowtext 1.5pt;
                                                                        mso-border-top-alt:solid windowtext 1.5pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                        background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;height:11.5pt'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><!--[if gte vml 1]><v:rect id="_x0000_s1031" style='position:absolute;
                                                                            margin-left:-24.95pt;margin-top:-.3pt;width:15.5pt;height:14.8pt;z-index:7;
                                                                            mso-position-horizontal-relative:text;mso-position-vertical-relative:text'
                                                                            wrapcoords="-1029 -1080 -1029 20520 22629 20520 22629 -1080 -1029 -1080">
                                                                            <o:lock v:ext="edit" aspectratio="t"/>
                                                                            <v:textbox style='mso-next-textbox:#_x0000_s1031'>
                                                                             <![if !mso]>
                                                                             <table cellpadding=0 cellspacing=0 width="100%">
                                                                              <tr>
                                                                               <td><![endif]>
                                                                               <div>
                                                                               <p class=MsoNormal><b style='mso-bidi-font-weight:normal'><span
                                                                               style='font-size:8.0pt;line-height:115%;font-family:Arial;text-transform:
                                                                               uppercase'><o:p>&nbsp;</o:p></span></b></p>
                                                                               </div>
                                                                               <![if !mso]></td>
                                                                              </tr>
                                                                             </table>
                                                                             <![endif]></v:textbox>
                                                                            <w:wrap type="tight"/>
                                                                           </v:rect><![endif]--><![if !vml]><img width=26 height=25
                                                                                                                  src="B6605DA2_arquivos/image007.gif" align=left hspace=12 v:shapes="_x0000_s1031"><![endif]><span
                                                                                    style='font-size:10.0pt'><span style='mso-spacerun:yes'>&nbsp;</span>SIM
                                                                                    (complete 3B, 3C e 3D)<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=222 colspan=12 rowspan=2 style='width:166.85pt;border-top:none;
                                                                        border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.5pt;
                                                                        mso-border-top-alt:solid windowtext 1.5pt;mso-border-top-alt:solid windowtext 1.5pt;
                                                                        mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext 1.5pt;
                                                                        background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;height:11.5pt'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><!--[if gte vml 1]><v:rect id="_x0000_s1032" style='position:absolute;
                                                                            margin-left:-89.3pt;margin-top:-127.2pt;width:15.5pt;height:14.8pt;
                                                                            z-index:6;mso-position-horizontal-relative:text;
                                                                            mso-position-vertical-relative:text' wrapcoords="-1029 -1080 -1029 20520 22629 20520 22629 -1080 -1029 -1080">
                                                                            <o:lock v:ext="edit" aspectratio="t"/>
                                                                            <v:textbox style='mso-next-textbox:#_x0000_s1032'>
                                                                             <![if !mso]>
                                                                             <table cellpadding=0 cellspacing=0 width="100%">
                                                                              <tr>
                                                                               <td><![endif]>
                                                                               <div>
                                                                               <p class=MsoNormal><b style='mso-bidi-font-weight:normal'><span
                                                                               style='font-size:8.0pt;line-height:115%;font-family:"Berlin Sans FB";
                                                                               mso-bidi-font-family:Arial;text-transform:uppercase'><o:p>&nbsp;</o:p></span></b></p>
                                                                               <p class=MsoNormal><b style='mso-bidi-font-weight:normal'><span
                                                                               style='font-size:8.0pt;line-height:115%;font-family:"Berlin Sans FB";
                                                                               mso-bidi-font-family:Arial;text-transform:uppercase'><o:p>&nbsp;</o:p></span></b></p>
                                                                               <p class=MsoNormal><b style='mso-bidi-font-weight:normal'><span
                                                                               style='font-size:8.0pt;line-height:115%;font-family:Arial;text-transform:
                                                                               uppercase'><o:p>&nbsp;</o:p></span></b></p>
                                                                               </div>
                                                                               <![if !mso]></td>
                                                                              </tr>
                                                                             </table>
                                                                             <![endif]></v:textbox>
                                                                            <w:wrap type="tight"/>
                                                                           </v:rect><![endif]--><![if !vml]><img width=27 height=26
                                                                                                                  src="B6605DA2_arquivos/image008.gif" align=left hspace=12
                                                                                                                  alt="Caixa de texto: " v:shapes="_x0000_s1032"><![endif]><span
                                                                                    style='font-size:10.0pt'>N&Atilde;O (passe para a se&ccedil;&atilde;o 4)<o:p></o:p></span></p>
                                                                    </td>
                                                                </tr>
                                                                <tr style='mso-yfti-irow:20;height:11.5pt'>
                                                                    <td width=35 valign=top style='width:26.3pt;border-top:none;border-left:solid windowtext 1.5pt;
                                                                        border-bottom:solid windowtext 1.0pt;border-right:none;mso-border-top-alt:
                                                                        solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:
                                                                        solid windowtext 1.5pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                        background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;height:11.5pt'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                </tr>
                                                                <tr style='mso-yfti-irow:21'>
                                                                    <td width=35 valign=top style='width:26.3pt;border-top:none;border-left:solid windowtext 1.5pt;
                                                                        border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                        mso-border-left-alt:solid windowtext 1.5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><span style='font-size:10.0pt'>3B<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=112 colspan=8 valign=top style='width:84.35pt;border:none;
                                                                        border-right:solid windowtext 1.0pt;mso-border-top-alt:solid windowtext .5pt;
                                                                        mso-border-left-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
                                                                        mso-border-left-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><span style='font-size:10.0pt'>PLACAS PLEURAS:<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=29 colspan=2 valign=top style='width:21.55pt;border-top:none;
                                                                        border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><b style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;
                                                                                                                       text-transform:uppercase'><o:p>&nbsp;</o:p></span></b></p>
                                                                    </td>
                                                                    <td width=38 colspan=5 valign=top style='width:28.75pt;border:none;
                                                                        border-right:solid windowtext 1.0pt;mso-border-top-alt:solid windowtext .5pt;
                                                                        mso-border-left-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
                                                                        mso-border-left-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><span style='font-size:10.0pt'>SIM<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=29 colspan=3 valign=top style='width:21.55pt;border-top:none;
                                                                        border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><b style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;
                                                                                                                       text-transform:uppercase'><o:p>&nbsp;</o:p></span></b></p>
                                                                    </td>
                                                                    <td width=454 colspan=34 valign=top style='width:340.3pt;border:none;
                                                                        border-right:solid windowtext 1.5pt;mso-border-top-alt:solid windowtext .5pt;
                                                                        mso-border-left-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><span style='font-size:10.0pt'>N&Atilde;O<o:p></o:p></span></p>
                                                                    </td>
                                                                </tr>
                                                                <tr style='mso-yfti-irow:22'>
                                                                    <td width=697 colspan=53 valign=top style='width:522.8pt;border-top:none;
                                                                        border-left:solid windowtext 1.5pt;border-bottom:none;border-right:solid windowtext 1.5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><span style='font-size:8.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                </tr>
                                                                <tr style='mso-yfti-irow:23;height:11.2pt'>
                                                                    <td width=89 colspan=5 valign=top style='width:66.9pt;border:none;border-left:
                                                                        solid windowtext 1.5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.2pt'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=87 colspan=6 valign=top style='width:65.3pt;border:none;border-bottom:
                                                                        solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:11.2pt'>
                                                                        <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           text-align:center;line-height:normal'><span style='font-size:10.0pt'>LOCAL<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=16 colspan=3 rowspan=5 valign=top style='width:11.95pt;border:none;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:11.2pt'>
                                                                        <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           text-align:center;line-height:normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=102 colspan=12 valign=top style='width:76.45pt;border:none;
                                                                        border-bottom:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:11.2pt'>
                                                                        <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           text-align:center;line-height:normal'><span style='font-size:10.0pt'>CALCIFICA&Ccedil;&Atilde;O<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=180 colspan=15 valign=top style='width:135.35pt;border:none;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:11.2pt'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><span style='font-size:9.0pt;mso-bidi-font-size:8.0pt'>EXTENS&Atilde;O:
                                                                                PAREDE (Combinado em perfil e frontal)</span><span style='font-size:8.0pt'><o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=222 colspan=12 valign=top style='width:166.85pt;border:none;
                                                                        border-right:solid windowtext 1.5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.2pt'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><span style='font-size:10.0pt'>LARGURA (OPCIONAL) <o:p></o:p></span></p>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><span style='font-size:8.0pt'>(m&iacute;nimo de 3 mm para
                                                                                marca&ccedil;&atilde;o)</span><span style='font-size:10.0pt'><o:p></o:p></span></p>
                                                                    </td>
                                                                </tr>
                                                                <tr style='mso-yfti-irow:24;height:2.75pt'>
                                                                    <td width=89 colspan=3 valign=top style='width:66.9pt;border-top:none;
                                                                            border-left:solid windowtext 1.5pt;border-bottom:none;border-right:solid windowtext 1.0pt;
                                                                            mso-border-left-alt:solid windowtext 1.5pt;mso-border-right-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt'>Frontal<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=29 valign=top style='width:21.5pt;border-top:none;border-left:none;
                                                                            border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>0<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=30 valign=top style='width:22.25pt;border-top:none;border-left:
                                                                            none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>D<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=29 colspan=2 valign=top style='width:21.55pt;border-top:none;
                                                                            border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>E<o:p></o:p></span></p>
                                                                        </td>
                                                                    <td width=33 colspan=4 style='width:24.8pt;border:solid windowtext 1.0pt;
                                                                        border-top:none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:2.75pt'>
                                                                        <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           text-align:center;line-height:normal'><span style='font-size:8.0pt'>0<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=33 colspan=3 style='width:24.7pt;border:solid windowtext 1.0pt;
                                                                        border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                        solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.75pt'>
                                                                        <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           text-align:center;line-height:normal'><span style='font-size:8.0pt'>D<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=36 colspan=5 style='width:26.95pt;border:solid windowtext 1.0pt;
                                                                        border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                        solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.75pt'>
                                                                        <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           text-align:center;line-height:normal'><span style='font-size:8.0pt'>E<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=19 colspan=2 valign=top style='width:14.5pt;border:none;border-right:
                                                                        solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:
                                                                        solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:
                                                                        0cm 5.4pt 0cm 5.4pt;height:2.75pt'>
                                                                        <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           text-align:center;line-height:normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=16 style='width:11.95pt;border-top:none;border-left:none;
                                                                        border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.75pt'>
                                                                        <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           text-align:center;line-height:normal'><span style='font-size:8.0pt'>0<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=18 colspan=3 style='width:13.55pt;border-top:none;border-left:none;
                                                                        border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.75pt'>
                                                                        <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           text-align:center;line-height:normal'><span style='font-size:8.0pt'>D<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=44 colspan=3 valign=top style='width:33.3pt;border:none;border-right:
                                                                        solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:
                                                                        solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:
                                                                        0cm 5.4pt 0cm 5.4pt;height:2.75pt'>
                                                                        <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           text-align:center;line-height:normal'><span style='font-size:8.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=21 style='width:15.95pt;border-top:none;border-left:none;
                                                                        border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.75pt'>
                                                                        <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           text-align:center;line-height:normal'><span style='font-size:8.0pt'>0<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=21 colspan=2 style='width:15.95pt;border-top:none;border-left:none;
                                                                        border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                        mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.75pt'>
                                                                        <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           text-align:center;line-height:normal'><span style='font-size:8.0pt'>E<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=58 colspan=5 valign=top style='width:43.2pt;border:none;border-right:
                                                                        solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:
                                                                        solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:
                                                                        0cm 5.4pt 0cm 5.4pt;height:2.75pt'>
                                                                        <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           text-align:center;line-height:normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=19 colspan=2 style='width:14.35pt;border:solid windowtext 1.0pt;
                                                                        border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                        solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.75pt'>
                                                                        <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           text-align:center;line-height:normal'><span style='font-size:8.0pt'>D<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=67 colspan=3 valign=top style='width:49.95pt;border:none;
                                                                        border-right:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        mso-border-left-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:2.75pt'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><span style='font-size:8.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                    <td width=20 colspan=2 style='width:14.7pt;border:solid windowtext 1.0pt;
                                                                        border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                        solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.75pt'>
                                                                        <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                           text-align:center;line-height:normal'><span style='font-size:8.0pt'>E<o:p></o:p></span></p>
                                                                    </td>
                                                                    <td width=100 colspan=3 valign=top style='width:74.8pt;border:none;
                                                                        border-right:solid windowtext 1.5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                        padding:0cm 5.4pt 0cm 5.4pt;height:2.75pt'>
                                                                        <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                           normal'><span style='font-size:8.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                    </td>
                                                                </tr>
                                                                <![if !supportMisalignedColumns]>
                                                                <tr height=0>
                                                                    <td width=35 style='border:none'></td>
                                                                    <td width=1 style='border:none'></td>
                                                                    <td width=19 style='border:none'></td>
                                                                    <td width=18 style='border:none'></td>
                                                                    <td width=17 style='border:none'></td>
                                                                    <td width=2 style='border:none'></td>
                                                                    <td width=27 style='border:none'></td>
                                                                    <td width=11 style='border:none'></td>
                                                                    <td width=19 style='border:none'></td>
                                                                    <td width=18 style='border:none'></td>
                                                                    <td width=10 style='border:none'></td>
                                                                    <td width=6 style='border:none'></td>
                                                                    <td width=5 style='border:none'></td>
                                                                    <td width=6 style='border:none'></td>
                                                                    <td width=13 style='border:none'></td>
                                                                    <td width=9 style='border:none'></td>
                                                                    <td width=8 style='border:none'></td>
                                                                    <td width=3 style='border:none'></td>
                                                                    <td width=18 style='border:none'></td>
                                                                    <td width=1 style='border:none'></td>
                                                                    <td width=14 style='border:none'></td>
                                                                    <td width=4 style='border:none'></td>
                                                                    <td width=1 style='border:none'></td>
                                                                    <td width=9 style='border:none'></td>
                                                                    <td width=11 style='border:none'></td>
                                                                    <td width=11 style='border:none'></td>
                                                                    <td width=7 style='border:none'></td>
                                                                    <td width=13 style='border:none'></td>
                                                                    <td width=16 style='border:none'></td>
                                                                    <td width=1 style='border:none'></td>
                                                                    <td width=15 style='border:none'></td>
                                                                    <td width=2 style='border:none'></td>
                                                                    <td width=31 style='border:none'></td>
                                                                    <td width=1 style='border:none'></td>
                                                                    <td width=13 style='border:none'></td>
                                                                    <td width=21 style='border:none'></td>
                                                                    <td width=14 style='border:none'></td>
                                                                    <td width=7 style='border:none'></td>
                                                                    <td width=13 style='border:none'></td>
                                                                    <td width=10 style='border:none'></td>
                                                                    <td width=17 style='border:none'></td>
                                                                    <td width=11 style='border:none'></td>
                                                                    <td width=6 style='border:none'></td>
                                                                    <td width=4 style='border:none'></td>
                                                                    <td width=15 style='border:none'></td>
                                                                    <td width=28 style='border:none'></td>
                                                                    <td width=33 style='border:none'></td>
                                                                    <td width=6 style='border:none'></td>
                                                                    <td width=4 style='border:none'></td>
                                                                    <td width=15 style='border:none'></td>
                                                                    <td width=28 style='border:none'></td>
                                                                    <td width=43 style='border:none'></td>
                                                                    <td width=29 style='border:none'></td>
                                                                </tr>
                                                                <![endif]>
                                                                </table>

                                                                <table class=MsoNormalTable border=1 cellspacing=0 cellpadding=0
                                                                       style='border-collapse:collapse;mso-table-layout-alt:fixed;border:none;
                                                                       mso-border-alt:solid windowtext .5pt;mso-yfti-tbllook:160;mso-padding-alt:
                                                                       0cm 5.4pt 0cm 5.4pt;mso-border-insideh:.5pt solid windowtext;mso-border-insidev:
                                                                       .5pt solid windowtext'>
                                                                    <tr style='mso-yfti-irow:25;height:2.7pt'>
                                                                        <td width=89 colspan=3 valign=top style='width:66.9pt;border-top:none;
                                                                            border-left:solid windowtext 1.5pt;border-bottom:none;border-right:solid windowtext 1.0pt;
                                                                            mso-border-left-alt:solid windowtext 1.5pt;mso-border-right-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt'>Frontal<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=29 valign=top style='width:21.5pt;border-top:none;border-left:none;
                                                                            border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>0<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=30 valign=top style='width:22.25pt;border-top:none;border-left:
                                                                            none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>D<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=29 colspan=2 valign=top style='width:21.55pt;border-top:none;
                                                                            border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>E<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=33 style='width:24.8pt;border:solid windowtext 1.0pt;border-top:
                                                                            none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>0<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=33 style='width:24.7pt;border-top:none;border-left:none;border-bottom:
                                                                            solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-top-alt:
                                                                            solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>D<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=36 colspan=3 style='width:26.95pt;border-top:none;border-left:none;
                                                                            border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>E<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=19 colspan=2 valign=top style='width:14.5pt;border:none;border-right:
                                                                            solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:
                                                                            solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:
                                                                            0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=16 colspan=2 style='width:11.95pt;border-top:none;border-left:none;
                                                                            border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>1<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=18 colspan=3 style='width:13.55pt;border-top:none;border-left:none;
                                                                            border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>2<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=24 colspan=4 valign=top style='width:17.95pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>3<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=20 valign=top style='width:15.35pt;border:none;border-right:solid windowtext 1.0pt;
                                                                            mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
                                                                            height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=21 colspan=3 style='width:15.95pt;border-top:none;border-left:none;
                                                                            border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>1<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=21 style='width:15.95pt;border-top:none;border-left:none;
                                                                            border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>2<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=26 colspan=2 style='width:19.25pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>3<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=32 colspan=3 valign=top style='width:23.95pt;border:none;
                                                                            border-right:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-left-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=19 style='width:14.35pt;border-top:none;border-left:none;
                                                                            border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>a<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=26 style='width:19.15pt;border:solid windowtext 1.0pt;border-left:
                                                                            none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>b<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=16 style='width:12.35pt;border-top:none;border-left:none;
                                                                            border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>c<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=25 colspan=2 valign=top style='width:18.8pt;border:none;border-right:
                                                                            solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:
                                                                            solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:
                                                                            0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=19 style='width:14.35pt;border:solid windowtext 1.0pt;border-left:
                                                                            none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>a<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=29 style='width:21.5pt;border:solid windowtext 1.0pt;border-left:
                                                                            none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>b<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 style='width:17.15pt;border-top:none;border-left:none;
                                                                            border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>c<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=48 valign=top style='width:36.15pt;border:none;border-right:solid windowtext 1.5pt;
                                                                            mso-border-left-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
                                                                            height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                    </tr>
                                                                    <tr style='mso-yfti-irow:26;height:11.35pt'>
                                                                        <td width=89 colspan=3 valign=top style='width:66.9pt;border-top:none;
                                                                            border-left:solid windowtext 1.5pt;border-bottom:none;border-right:solid windowtext 1.0pt;
                                                                            mso-border-left-alt:solid windowtext 1.5pt;mso-border-right-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt'>Diafragma<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=29 valign=top style='width:21.5pt;border-top:none;border-left:none;
                                                                            border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>0<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=30 valign=top style='width:22.25pt;border-top:none;border-left:
                                                                            none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>D<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=29 colspan=2 valign=top style='width:21.55pt;border-top:none;
                                                                            border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>E<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=33 style='width:24.8pt;border:solid windowtext 1.0pt;border-top:
                                                                            none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>0<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=33 style='width:24.7pt;border-top:none;border-left:none;border-bottom:
                                                                            solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-top-alt:
                                                                            solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>D<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=36 colspan=3 style='width:26.95pt;border-top:none;border-left:none;
                                                                            border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>E<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=19 colspan=2 rowspan=2 valign=top style='width:14.5pt;border:none;
                                                                            mso-border-left-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
                                                                            height:11.35pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:9.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=136 colspan=15 rowspan=2 valign=top style='width:102.1pt;
                                                                            border:none;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt;mso-bidi-font-size:9.0pt'>At&eacute; 1/4
                                                                                    da parede lateral <o:p></o:p></span></p>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt;mso-bidi-font-size:9.0pt'>1/4 a 1/2 da
                                                                                    parede lateral<o:p></o:p></span></p>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt;mso-bidi-font-size:9.0pt'>&gt; 1/2 da
                                                                                    parede lateral</span><span style='font-size:9.0pt'><o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=29 colspan=2 rowspan=2 style='width:21.65pt;border:none;padding:
                                                                            0cm 5.4pt 0cm 5.4pt;height:11.35pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-indent:
                                                                               -4.05pt;line-height:normal'><span style='font-size:8.0pt;mso-bidi-font-size:
                                                                                    9.0pt'>=1<o:p></o:p></span></p>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-indent:
                                                                               -4.05pt;line-height:normal'><span style='font-size:8.0pt;mso-bidi-font-size:
                                                                                    9.0pt'>=2<o:p></o:p></span></p>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;text-indent:
                                                                               -4.05pt;line-height:normal'><span style='font-size:8.0pt;mso-bidi-font-size:
                                                                                    9.0pt'>=3</span><span style='font-size:9.0pt'><o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=95 colspan=6 rowspan=2 style='width:71.5pt;border:none;padding:
                                                                            0cm 5.4pt 0cm 5.4pt;height:11.35pt'>
                                                                            <p class=MsoNormal align=right style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:right;line-height:normal'><span style='font-size:8.0pt;mso-bidi-font-size:
                                                                                    10.0pt'>3 a 5 mm <o:p></o:p></span></p>
                                                                            <p class=MsoNormal align=right style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:right;line-height:normal'><span style='font-size:8.0pt;mso-bidi-font-size:
                                                                                    10.0pt'>5 a 10 mm <o:p></o:p></span></p>
                                                                            <p class=MsoNormal align=right style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:right;line-height:normal'><span style='font-size:8.0pt;mso-bidi-font-size:
                                                                                    10.0pt'><span style='mso-spacerun:yes'>&nbsp;</span>&gt; 10 mm<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=123 colspan=5 rowspan=2 style='width:92.45pt;border:none;
                                                                            border-right:solid windowtext 1.5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt'>= a<o:p></o:p></span></p>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt'>= b<o:p></o:p></span></p>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt'>= c<o:p></o:p></span></p>
                                                                        </td>
                                                                    </tr>
                                                                    <tr style='mso-yfti-irow:27;height:2.7pt'>
                                                                        <td width=89 colspan=3 valign=top style='width:66.9pt;border-top:none;
                                                                            border-left:solid windowtext 1.5pt;border-bottom:none;border-right:solid windowtext 1.0pt;
                                                                            mso-border-left-alt:solid windowtext 1.5pt;mso-border-right-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt'>Outros locais<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=29 style='width:21.5pt;border-top:none;border-left:none;border-bottom:
                                                                            solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-top-alt:
                                                                            solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>0<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=30 style='width:22.25pt;border-top:none;border-left:none;
                                                                            border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>D<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=29 colspan=2 style='width:21.55pt;border-top:none;border-left:none;
                                                                            border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>E<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=33 style='width:24.8pt;border:solid windowtext 1.0pt;border-top:
                                                                            none;mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>0<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=33 style='width:24.7pt;border-top:none;border-left:none;border-bottom:
                                                                            solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;mso-border-top-alt:
                                                                            solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>D<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=36 colspan=3 style='width:26.95pt;border-top:none;border-left:none;
                                                                            border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:2.7pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt'>E<o:p></o:p></span></p>
                                                                        </td>
                                                                    </tr>
                                                                    <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>
                                                                        <td width=35 valign=top style='width:25.9pt;border-top:none;border-left:solid windowtext 1.5pt;
                                                                            border-bottom:solid windowtext 1.0pt;border-right:none;mso-border-left-alt:
                                                                            solid windowtext 1.5pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=255 colspan=12 valign=top style='width:191.6pt;border:none;
                                                                            border-bottom:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=34 colspan=4 valign=top style='width:25.6pt;border:none;border-bottom:
                                                                            solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=38 colspan=5 valign=top style='width:28.45pt;border:none;
                                                                            border-bottom:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=40 colspan=5 valign=top style='width:29.75pt;border:none;
                                                                            border-bottom:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=295 colspan=17 valign=top style='width:221.5pt;border-top:none;
                                                                            border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.5pt;
                                                                            mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext 1.5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                    </tr>
                                                                    <tr style='mso-yfti-irow:1;height:5.65pt;mso-height-rule:exactly'>
                                                                        <td width=697 colspan=44 style='width:522.8pt;border-top:none;border-left:
                                                                            solid windowtext 1.5pt;border-bottom:none;border-right:solid windowtext 1.5pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
                                                                            height:5.65pt;mso-height-rule:exactly'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                    </tr>
                                                                    <tr style='mso-yfti-irow:2;height:8.05pt'>
                                                                        <td width=35 style='width:25.9pt;border:solid windowtext 1.0pt;border-left:
                                                                            solid windowtext 1.5pt;mso-border-alt:solid windowtext .5pt;mso-border-left-alt:
                                                                            solid windowtext 1.5pt;padding:0cm 5.4pt 0cm 5.4pt;height:8.05pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'>3C<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=274 colspan=14 style='width:205.75pt;border:none;border-right:solid windowtext 1.0pt;
                                                                            mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
                                                                            height:8.05pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'>OBLITERA&Ccedil;&Atilde;O DO SEIO
                                                                                    COSTOFRENICO:<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=29 colspan=4 style='width:22.0pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:8.05pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:10.0pt'>0<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=32 colspan=5 style='width:23.7pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:8.05pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:10.0pt'>D<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=32 colspan=3 style='width:23.95pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:8.05pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:10.0pt'>E<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=295 colspan=17 style='width:221.5pt;border:none;border-right:solid windowtext 1.5pt;
                                                                            mso-border-left-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
                                                                            height:8.05pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                    </tr>
                                                                    <tr style='mso-yfti-irow:3;height:5.65pt;mso-height-rule:exactly'>
                                                                        <td width=697 colspan=44 style='width:522.8pt;border-top:none;border-left:
                                                                            solid windowtext 1.5pt;border-bottom:none;border-right:solid windowtext 1.5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt;height:5.65pt;mso-height-rule:exactly'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                    </tr>
                                                                    <tr style='mso-yfti-irow:4'>
                                                                        <td width=35 valign=top style='width:25.9pt;border:solid windowtext 1.0pt;
                                                                            border-left:solid windowtext 1.5pt;mso-border-alt:solid windowtext .5pt;
                                                                            mso-border-left-alt:solid windowtext 1.5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'>3D<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=233 colspan=11 valign=top style='width:174.7pt;border-top:solid windowtext 1.0pt;
                                                                            border-left:none;border-bottom:none;border-right:solid windowtext 1.0pt;
                                                                            mso-border-left-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
                                                                            mso-border-left-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'>ESPESSAMENTO PLEURAL DIFUSO: <o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 valign=top style='width:16.9pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><b style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;
                                                                                                                           text-transform:uppercase'><o:p>&nbsp;</o:p></span></b></p>
                                                                        </td>
                                                                        <td width=55 colspan=7 valign=top style='width:40.95pt;border-top:solid windowtext 1.0pt;
                                                                            border-left:none;border-bottom:none;border-right:solid windowtext 1.0pt;
                                                                            mso-border-left-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
                                                                            mso-border-left-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'>SIM<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=19 colspan=3 valign=top style='width:14.6pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><b style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;
                                                                                                                           text-transform:uppercase'><o:p>&nbsp;</o:p></span></b></p>
                                                                        </td>
                                                                        <td width=49 colspan=5 valign=top style='width:36.4pt;border:none;border-top:
                                                                            solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;mso-border-top-alt:
                                                                            solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'>N&Atilde;O<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=284 colspan=16 valign=top style='width:213.35pt;border-top:solid windowtext 1.0pt;
                                                                            border-left:none;border-bottom:none;border-right:solid windowtext 1.5pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext 1.5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                    </tr>
                                                                    <tr style='mso-yfti-irow:5;height:8.5pt;mso-height-rule:exactly'>
                                                                        <td width=35 valign=top style='width:25.9pt;border:none;border-left:solid windowtext 1.5pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
                                                                            height:8.5pt;mso-height-rule:exactly'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=233 colspan=11 valign=top style='width:174.7pt;border:none;
                                                                            padding:0cm 5.4pt 0cm 5.4pt;height:8.5pt;mso-height-rule:exactly'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=23 valign=top style='width:16.9pt;border:none;padding:0cm 5.4pt 0cm 5.4pt;
                                                                            height:8.5pt;mso-height-rule:exactly'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=55 colspan=7 valign=top style='width:40.95pt;border:none;
                                                                            padding:0cm 5.4pt 0cm 5.4pt;height:8.5pt;mso-height-rule:exactly'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=19 colspan=3 valign=top style='width:14.6pt;border:none;padding:
                                                                            0cm 5.4pt 0cm 5.4pt;height:8.5pt;mso-height-rule:exactly'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=49 colspan=5 valign=top style='width:36.4pt;border:none;padding:
                                                                            0cm 5.4pt 0cm 5.4pt;height:8.5pt;mso-height-rule:exactly'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=284 colspan=16 valign=top style='width:213.35pt;border:none;
                                                                            border-right:solid windowtext 1.5pt;padding:0cm 5.4pt 0cm 5.4pt;height:8.5pt;
                                                                            mso-height-rule:exactly'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                    </tr>
                                                                    <tr style='mso-yfti-irow:6'>
                                                                        <td width=51 colspan=2 valign=top style='width:38.6pt;border:none;border-left:
                                                                            solid windowtext 1.5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=96 colspan=4 valign=top style='width:72.15pt;border:none;
                                                                            padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=29 colspan=2 valign=top style='width:21.55pt;border:none;
                                                                            padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=114 colspan=5 style='width:85.2pt;border:none;border-bottom:solid windowtext 1.0pt;
                                                                            mso-border-bottom-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:10.0pt'>CALCIFICA&Ccedil;&Atilde;O<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=19 colspan=2 valign=top style='width:14.15pt;border:none;
                                                                            padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=180 colspan=19 valign=top style='width:135.2pt;border:none;
                                                                            padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'>EXTENS&Atilde;O: PAREDE </span><span
                                                                                    style='font-size:8.0pt;mso-bidi-font-size:10.0pt'>(Combinado em perfil e
                                                                                    frontal)</span><span style='font-size:10.0pt'><o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=208 colspan=10 valign=top style='width:155.95pt;border:none;
                                                                            border-right:solid windowtext 1.5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'>LARGURA (OPCIONAL) </span><span
                                                                                    style='font-size:8.0pt;mso-bidi-font-size:10.0pt'>(m&iacute;nimo de 3 mm p/
                                                                                    marca&ccedil;&atilde;o)</span><span style='font-size:10.0pt'><o:p></o:p></span></p>
                                                                        </td>
                                                                    </tr>
                                                                    <![if !supportMisalignedColumns]>
                                                                    <tr height=0>
                                                                        <td width=35 style='border:none'></td>
                                                                        <td width=17 style='border:none'></td>
                                                                        <td width=38 style='border:none'></td>
                                                                        <td width=29 style='border:none'></td>
                                                                        <td width=30 style='border:none'></td>
                                                                        <td width=0 style='border:none'></td>
                                                                        <td width=29 style='border:none'></td>
                                                                        <td width=0 style='border:none'></td>
                                                                        <td width=16 style='border:none'></td>
                                                                        <td width=33 style='border:none'></td>
                                                                        <td width=33 style='border:none'></td>
                                                                        <td width=9 style='border:none'></td>
                                                                        <td width=23 style='border:none'></td>
                                                                        <td width=4 style='border:none'></td>
                                                                        <td width=15 style='border:none'></td>
                                                                        <td width=5 style='border:none'></td>
                                                                        <td width=11 style='border:none'></td>
                                                                        <td width=5 style='border:none'></td>
                                                                        <td width=9 style='border:none'></td>
                                                                        <td width=6 style='border:none'></td>
                                                                        <td width=3 style='border:none'></td>
                                                                        <td width=15 style='border:none'></td>
                                                                        <td width=2 style='border:none'></td>
                                                                        <td width=6 style='border:none'></td>
                                                                        <td width=2 style='border:none'></td>
                                                                        <td width=20 style='border:none'></td>
                                                                        <td width=10 style='border:none'></td>
                                                                        <td width=11 style='border:none'></td>
                                                                        <td width=1 style='border:none'></td>
                                                                        <td width=21 style='border:none'></td>
                                                                        <td width=15 style='border:none'></td>
                                                                        <td width=10 style='border:none'></td>
                                                                        <td width=18 style='border:none'></td>
                                                                        <td width=11 style='border:none'></td>
                                                                        <td width=3 style='border:none'></td>
                                                                        <td width=19 style='border:none'></td>
                                                                        <td width=26 style='border:none'></td>
                                                                        <td width=16 style='border:none'></td>
                                                                        <td width=21 style='border:none'></td>
                                                                        <td width=4 style='border:none'></td>
                                                                        <td width=19 style='border:none'></td>
                                                                        <td width=29 style='border:none'></td>
                                                                        <td width=23 style='border:none'></td>
                                                                        <td width=48 style='border:none'></td>
                                                                    </tr>
                                                                    <![endif]>
                                                                </table>

                                                                <table class=MsoNormalTable border=1 cellspacing=0 cellpadding=0
                                                                       style='border-collapse:collapse;mso-table-layout-alt:fixed;border:none;
                                                                       mso-border-alt:solid windowtext .5pt;mso-yfti-tbllook:160;mso-padding-alt:
                                                                       0cm 5.4pt 0cm 5.4pt;mso-border-insideh:.5pt solid windowtext;mso-border-insidev:
                                                                       .5pt solid windowtext'>
                                                                    <tr style='mso-yfti-irow:7'>
                                                                        <td width=52 colspan=3 style='width:39.1pt;border-top:none;border-left:solid windowtext 1.5pt;
                                                                            border-bottom:none;border-right:solid windowtext 1.0pt;mso-border-left-alt:
                                                                            solid windowtext 1.5pt;mso-border-right-alt:solid windowtext .5pt;padding:
                                                                            0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:6.0pt;mso-bidi-font-size:10.0pt'>Parede em
                                                                                    perfil<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=32 colspan=3 style='width:23.85pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt;
                                                                                    mso-bidi-font-size:10.0pt'>0<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=32 colspan=2 style='width:23.9pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt;
                                                                                    mso-bidi-font-size:10.0pt'>D<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=32 colspan=3 style='width:23.9pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt;
                                                                                    mso-bidi-font-size:10.0pt'>E<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=29 colspan=3 valign=top style='width:21.55pt;border:none;
                                                                            border-right:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-left-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=38 colspan=3 style='width:1.0cm;border-top:none;border-left:none;
                                                                            border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt;
                                                                                    mso-bidi-font-size:10.0pt'>0<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=38 colspan=5 style='width:1.0cm;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt;
                                                                                    mso-bidi-font-size:10.0pt'>D<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=38 colspan=4 style='width:28.5pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt;
                                                                                    mso-bidi-font-size:10.0pt'>E<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=19 valign=top style='width:14.15pt;border:none;border-right:solid windowtext 1.0pt;
                                                                            mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=19 colspan=2 style='width:14.6pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt'>0<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=19 colspan=2 style='width:14.15pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt'>D<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=19 colspan=2 valign=top style='width:14.2pt;border:none;border-bottom:
                                                                            solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:
                                                                            solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;padding:
                                                                            0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=28 colspan=2 valign=top style='width:21.25pt;border:none;
                                                                            border-right:solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=19 colspan=3 style='width:14.2pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt'>0<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=19 colspan=2 style='width:14.15pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt'>E<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=57 colspan=5 valign=top style='width:42.65pt;border:none;
                                                                            border-right:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-left-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=19 colspan=2 style='width:14.2pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt'>D<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=19 colspan=2 valign=top style='width:14.2pt;border:none;border-bottom:
                                                                            solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:
                                                                            solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;padding:
                                                                            0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=19 colspan=2 valign=top style='width:14.15pt;border:none;
                                                                            border-bottom:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=32 colspan=2 valign=top style='width:23.7pt;border:none;border-right:
                                                                            solid windowtext 1.0pt;mso-border-right-alt:solid windowtext .5pt;padding:
                                                                            0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=25 colspan=2 valign=top style='width:18.85pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt'>E<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=94 colspan=7 valign=top style='width:70.85pt;border:none;
                                                                            border-right:solid windowtext 1.5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                    </tr>
                                                                    <tr style='mso-yfti-irow:8'>
                                                                        <td width=52 colspan=3 style='width:39.1pt;border-top:none;border-left:solid windowtext 1.5pt;
                                                                            border-bottom:none;border-right:solid windowtext 1.0pt;mso-border-left-alt:
                                                                            solid windowtext 1.5pt;mso-border-right-alt:solid windowtext .5pt;padding:
                                                                            0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:6.0pt;mso-bidi-font-size:10.0pt'>Frontal<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=32 colspan=3 style='width:23.85pt;border-top:none;border-left:none;
                                                                            border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt;
                                                                                    mso-bidi-font-size:10.0pt'>0<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=32 colspan=2 style='width:23.9pt;border-top:none;border-left:none;
                                                                            border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt;
                                                                                    mso-bidi-font-size:10.0pt'>D<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=32 colspan=3 style='width:23.9pt;border-top:none;border-left:none;
                                                                            border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt;
                                                                                    mso-bidi-font-size:10.0pt'>E<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=29 colspan=3 valign=top style='width:21.55pt;border:none;
                                                                            border-right:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-left-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=38 colspan=3 style='width:1.0cm;border-top:none;border-left:none;
                                                                            border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt;
                                                                                    mso-bidi-font-size:10.0pt'>0<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=38 colspan=5 style='width:1.0cm;border-top:none;border-left:none;
                                                                            border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt;
                                                                                    mso-bidi-font-size:10.0pt'>D<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=38 colspan=4 style='width:28.5pt;border-top:none;border-left:none;
                                                                            border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:8.0pt;
                                                                                    mso-bidi-font-size:10.0pt'>E<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=19 valign=top style='width:14.15pt;border:none;border-right:solid windowtext 1.0pt;
                                                                            mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=19 colspan=2 valign=top style='width:14.6pt;border-top:none;
                                                                            border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt'>1<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=19 colspan=2 valign=top style='width:14.15pt;border-top:none;
                                                                            border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt'>2<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=19 colspan=2 valign=top style='width:14.2pt;border-top:none;
                                                                            border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt'>3<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=28 colspan=2 valign=top style='width:21.25pt;border:none;
                                                                            border-right:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-left-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=19 colspan=3 valign=top style='width:14.2pt;border-top:none;
                                                                            border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt'>1<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=19 colspan=2 valign=top style='width:14.15pt;border-top:none;
                                                                            border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt'>2<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=19 colspan=3 valign=top style='width:14.35pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt'>3<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=38 colspan=2 valign=top style='width:28.3pt;border:none;border-right:
                                                                            solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:
                                                                            solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:
                                                                            0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=19 colspan=2 valign=top style='width:14.2pt;border-top:none;
                                                                            border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt'>a<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=19 colspan=2 valign=top style='width:14.2pt;border-top:none;
                                                                            border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt'>b<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=19 colspan=2 valign=top style='width:14.15pt;border-top:none;
                                                                            border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt'>c<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=32 colspan=2 valign=top style='width:23.7pt;border:none;border-right:
                                                                            solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;mso-border-left-alt:
                                                                            solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:
                                                                            0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=25 colspan=2 valign=top style='width:18.85pt;border-top:none;
                                                                            border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt'>a<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=24 colspan=2 valign=top style='width:17.7pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt'>b<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=24 colspan=2 valign=top style='width:17.7pt;border-top:none;
                                                                            border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt'>c<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=47 colspan=3 valign=top style='width:35.45pt;border:none;
                                                                            border-right:solid windowtext 1.5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                    </tr>
                                                                    <tr style='mso-yfti-irow:9'>
                                                                        <td width=52 colspan=3 valign=top style='width:39.1pt;border-top:none;
                                                                            border-left:solid windowtext 1.5pt;border-bottom:solid windowtext 1.5pt;
                                                                            border-right:none;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=96 colspan=8 valign=top style='width:71.65pt;border:none;
                                                                            border-bottom:solid windowtext 1.5pt;mso-border-top-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=29 colspan=3 valign=top style='width:21.55pt;border:none;
                                                                            border-bottom:solid windowtext 1.5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=114 colspan=12 valign=top style='width:85.2pt;border:none;
                                                                            border-bottom:solid windowtext 1.5pt;mso-border-top-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=19 valign=top style='width:14.15pt;border:none;border-bottom:solid windowtext 1.5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=123 colspan=13 valign=top style='width:92.55pt;border:none;
                                                                            border-bottom:solid windowtext 1.5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:7.0pt;mso-bidi-font-size:10.0pt'>At&eacute;
                                                                                    1/4 da parede lateral<o:p></o:p></span></p>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:7.0pt;mso-bidi-font-size:10.0pt'>1/4 a 1/2 da
                                                                                    parede lateral<o:p></o:p></span></p>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:7.0pt;mso-bidi-font-size:10.0pt'>&gt; 1/2 da
                                                                                    parede lateral<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=57 colspan=5 valign=top style='width:42.65pt;border:none;
                                                                            border-bottom:solid windowtext 1.5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:7.0pt;mso-bidi-font-size:10.0pt'>=1<o:p></o:p></span></p>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:7.0pt;mso-bidi-font-size:10.0pt'>=2<o:p></o:p></span></p>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:7.0pt;mso-bidi-font-size:10.0pt'>=3<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=88 colspan=8 style='width:66.25pt;border:none;border-bottom:solid windowtext 1.5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal align=right style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:right;line-height:normal'><span style='font-size:7.0pt;mso-bidi-font-size:
                                                                                    10.0pt'>3 a 5 mm<o:p></o:p></span></p>
                                                                            <p class=MsoNormal align=right style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:right;line-height:normal'><span style='font-size:7.0pt;mso-bidi-font-size:
                                                                                    10.0pt'>5 a 10 mm<o:p></o:p></span></p>
                                                                            <p class=MsoNormal align=right style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:right;line-height:normal'><span style='font-size:7.0pt;mso-bidi-font-size:
                                                                                    10.0pt'><span style='mso-spacerun:yes'>&nbsp;</span>&gt; 10 mm<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=120 colspan=9 valign=top style='width:89.7pt;border-top:none;
                                                                            border-left:none;border-bottom:solid windowtext 1.5pt;border-right:solid windowtext 1.5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:7.0pt;mso-bidi-font-size:10.0pt'>= a<o:p></o:p></span></p>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:7.0pt;mso-bidi-font-size:10.0pt'>= b<o:p></o:p></span></p>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:7.0pt;mso-bidi-font-size:10.0pt'>= c<o:p></o:p></span></p>
                                                                        </td>
                                                                    </tr>
                                                                    <tr style='mso-yfti-irow:10;height:5.65pt;mso-height-rule:exactly'>
                                                                        <td width=697 colspan=62 valign=top style='width:522.8pt;border:none;
                                                                            border-bottom:solid windowtext 1.5pt;mso-border-top-alt:solid windowtext 1.5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt;height:5.65pt;mso-height-rule:exactly'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                    </tr>
                                                                    <tr style='mso-yfti-irow:11;height:5.65pt;mso-height-rule:exactly'>
                                                                        <td width=35 valign=top style='width:25.9pt;border-top:none;border-left:solid windowtext 1.5pt;
                                                                            border-bottom:solid windowtext 1.0pt;border-right:none;mso-border-top-alt:
                                                                            solid windowtext 1.5pt;mso-border-top-alt:solid windowtext 1.5pt;mso-border-left-alt:
                                                                            solid windowtext 1.5pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                            background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;height:5.65pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=182 colspan=17 valign=top style='width:136.65pt;border:none;
                                                                            mso-border-top-alt:solid windowtext 1.5pt;background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;
                                                                            height:5.65pt;mso-height-rule:exactly'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=16 colspan=2 valign=top style='width:11.85pt;border:none;
                                                                            border-bottom:solid windowtext 1.0pt;mso-border-top-alt:solid windowtext 1.5pt;
                                                                            mso-border-top-alt:solid windowtext 1.5pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                            background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;height:5.65pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=180 colspan=17 valign=top style='width:135.05pt;border:none;
                                                                            mso-border-top-alt:solid windowtext 1.5pt;background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;
                                                                            height:5.65pt;mso-height-rule:exactly'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=20 colspan=4 valign=top style='width:15.05pt;border:none;
                                                                            border-bottom:solid windowtext 1.0pt;mso-border-top-alt:solid windowtext 1.5pt;
                                                                            mso-border-top-alt:solid windowtext 1.5pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                            background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;height:5.65pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=264 colspan=21 valign=top style='width:198.3pt;border:none;
                                                                            border-right:solid windowtext 1.5pt;mso-border-top-alt:solid windowtext 1.5pt;
                                                                            background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;height:5.65pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                    </tr>
                                                                    <tr style='mso-yfti-irow:12'>
                                                                        <td width=35 valign=top style='width:25.9pt;border-top:none;border-left:solid windowtext 1.5pt;
                                                                            border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                            mso-border-left-alt:solid windowtext 1.5pt;background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><b style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt'>4A<o:p></o:p></span></b></p>
                                                                        </td>
                                                                        <td width=182 colspan=17 valign=top style='width:136.65pt;border:none;
                                                                            border-right:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-left-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
                                                                            background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'>OUTRAS ANORMALIDADES:<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=16 colspan=2 valign=top style='width:11.85pt;border-top:none;
                                                                            border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><b style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;
                                                                                                                           text-transform:uppercase'><o:p>&nbsp;</o:p></span></b></p>
                                                                        </td>
                                                                        <td width=180 colspan=17 valign=top style='width:135.05pt;border:none;
                                                                            border-right:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-left-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
                                                                            background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:9.0pt'>SIM (complete 4B)<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=20 colspan=4 valign=top style='width:15.05pt;border-top:none;
                                                                            border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><b style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;
                                                                                                                           text-transform:uppercase'><o:p>&nbsp;</o:p></span></b></p>
                                                                        </td>
                                                                        <td width=264 colspan=21 valign=top style='width:198.3pt;border:none;
                                                                            border-right:solid windowtext 1.5pt;mso-border-left-alt:solid windowtext .5pt;
                                                                            background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:9.0pt'>N&Atilde;O (finaliza leitura)<o:p></o:p></span></p>
                                                                        </td>
                                                                    </tr>
                                                                    <tr style='mso-yfti-irow:13;height:5.65pt;mso-height-rule:exactly'>
                                                                        <td width=35 valign=top style='width:25.9pt;border-top:none;border-left:solid windowtext 1.5pt;
                                                                            border-bottom:solid windowtext 1.0pt;border-right:none;mso-border-top-alt:
                                                                            solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:
                                                                            solid windowtext 1.5pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                            background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;height:5.65pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=182 colspan=17 valign=top style='width:136.65pt;border:none;
                                                                            border-bottom:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                            background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;height:5.65pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=16 colspan=2 valign=top style='width:11.85pt;border:none;
                                                                            border-bottom:solid windowtext 1.0pt;mso-border-top-alt:solid windowtext .5pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                            background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;height:5.65pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=180 colspan=17 valign=top style='width:135.05pt;border:none;
                                                                            border-bottom:solid windowtext 1.0pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                            background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;height:5.65pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=20 colspan=4 valign=top style='width:15.05pt;border:none;
                                                                            border-bottom:solid windowtext 1.0pt;mso-border-top-alt:solid windowtext .5pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                            background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;height:5.65pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=264 colspan=21 valign=top style='width:198.3pt;border-top:none;
                                                                            border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.5pt;
                                                                            mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext 1.5pt;
                                                                            background:#F2F2F2;padding:0cm 5.4pt 0cm 5.4pt;height:5.65pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                    </tr>
                                                                    <tr style='mso-yfti-irow:14;height:3.4pt'>
                                                                        <td width=35 valign=top style='width:25.9pt;border-top:none;border-left:solid windowtext 1.5pt;
                                                                            border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                            mso-border-left-alt:solid windowtext 1.5pt;padding:0cm 5.4pt 0cm 5.4pt;
                                                                            height:3.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'>4B<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=663 colspan=61 valign=top style='width:496.9pt;border:none;
                                                                            border-right:solid windowtext 1.5pt;mso-border-top-alt:solid windowtext .5pt;
                                                                            mso-border-left-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
                                                                            height:3.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:9.0pt'>S&Iacute;MBOLOS (vide legenda no
                                                                                    verso):<o:p></o:p></span></p>
                                                                        </td>
                                                                    </tr>
                                                                    <tr style='mso-yfti-irow:15;height:5.65pt;mso-height-rule:exactly'>
                                                                        <td width=35 valign=top style='width:25.9pt;border:none;border-left:solid windowtext 1.5pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
                                                                            height:5.65pt;mso-height-rule:exactly'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=663 colspan=61 valign=top style='width:496.9pt;border:none;
                                                                            border-right:solid windowtext 1.5pt;padding:0cm 5.4pt 0cm 5.4pt;height:5.65pt;
                                                                            mso-height-rule:exactly'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                    </tr>
                                                                    <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;height:11.35pt;mso-height-rule:
                                                                        exactly'>
                                                                        <td width=37 colspan=2 rowspan=2 style='width:27.55pt;border-top:none;
                                                                            border-left:solid windowtext 1.5pt;border-bottom:solid windowtext 1.0pt;
                                                                            border-right:solid windowtext 1.0pt;mso-border-left-alt:solid windowtext 1.5pt;
                                                                            mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:exactly'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                        <td width=23 colspan=2 style='width:17.05pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:5.0pt;
                                                                                    mso-bidi-font-size:8.0pt;font-family:"Times New Roman"'>aa<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 style='width:17.1pt;border:solid windowtext 1.0pt;border-left:
                                                                            none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:exactly'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:5.0pt;
                                                                                    mso-bidi-font-size:8.0pt;font-family:"Times New Roman"'>at<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 colspan=2 style='width:17.05pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:5.0pt;
                                                                                    mso-bidi-font-size:8.0pt;font-family:"Times New Roman"'>ax<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 colspan=2 style='width:17.1pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:5.0pt;
                                                                                    mso-bidi-font-size:8.0pt;font-family:"Times New Roman"'>bu<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 colspan=3 style='width:17.05pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:5.0pt;
                                                                                    mso-bidi-font-size:8.0pt;font-family:"Times New Roman"'>ca<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 style='width:17.1pt;border:solid windowtext 1.0pt;border-left:
                                                                            none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:exactly'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:5.0pt;
                                                                                    mso-bidi-font-size:8.0pt;font-family:"Times New Roman"'>cg<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 colspan=3 style='width:17.05pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:5.0pt;
                                                                                    mso-bidi-font-size:8.0pt;font-family:"Times New Roman"'>cn<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 colspan=3 style='width:17.1pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:5.0pt;
                                                                                    mso-bidi-font-size:8.0pt;font-family:"Times New Roman"'>co<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 colspan=2 style='width:17.05pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:5.0pt;
                                                                                    mso-bidi-font-size:8.0pt;font-family:"Times New Roman"'>cp<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 colspan=3 style='width:17.1pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:5.0pt;
                                                                                    mso-bidi-font-size:8.0pt;font-family:"Times New Roman"'>cv<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 style='width:17.1pt;border:solid windowtext 1.0pt;border-left:
                                                                            none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:exactly'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:5.0pt;
                                                                                    mso-bidi-font-size:8.0pt;font-family:"Times New Roman"'>di<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 colspan=3 style='width:17.05pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:5.0pt;
                                                                                    mso-bidi-font-size:8.0pt;font-family:"Times New Roman"'>ef<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 colspan=2 style='width:17.1pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal align=center style='margin-top:0cm;margin-right:-4.25pt;
                                                                               margin-bottom:0cm;margin-left:-7.1pt;margin-bottom:.0001pt;text-align:center;
                                                                               text-indent:.4pt;line-height:normal'><span style='font-size:5.0pt;mso-bidi-font-size:
                                                                                    8.0pt;font-family:"Times New Roman"'>em<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 colspan=2 style='width:17.05pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:5.0pt;
                                                                                    mso-bidi-font-size:8.0pt;font-family:"Times New Roman"'>es<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 colspan=2 style='width:17.1pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:5.0pt;
                                                                                    mso-bidi-font-size:8.0pt;font-family:"Times New Roman"'>fr<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 colspan=2 style='width:17.05pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:5.0pt;
                                                                                    mso-bidi-font-size:8.0pt;font-family:"Times New Roman"'>hi<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 colspan=3 style='width:17.1pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:5.0pt;
                                                                                    mso-bidi-font-size:8.0pt;font-family:"Times New Roman"'>ho<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 colspan=3 style='width:17.05pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:5.0pt;
                                                                                    mso-bidi-font-size:8.0pt;font-family:"Times New Roman"'>id<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 colspan=2 style='width:17.1pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:5.0pt;
                                                                                    mso-bidi-font-size:8.0pt;font-family:"Times New Roman"'>ih<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 colspan=2 style='width:17.1pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:5.0pt;
                                                                                    mso-bidi-font-size:8.0pt;font-family:"Times New Roman"'>kl<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 colspan=2 style='width:17.05pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal align=center style='margin-top:0cm;margin-right:-7.75pt;
                                                                               margin-bottom:0cm;margin-left:-8.25pt;margin-bottom:.0001pt;text-align:center;
                                                                               line-height:normal'><span style='font-size:5.0pt;mso-bidi-font-size:8.0pt;
                                                                                    font-family:"Times New Roman"'>me<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 colspan=2 style='width:17.1pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:5.0pt;
                                                                                    mso-bidi-font-size:8.0pt;font-family:"Times New Roman"'>pa<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 colspan=2 style='width:17.05pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:5.0pt;
                                                                                    mso-bidi-font-size:8.0pt;font-family:"Times New Roman"'>pb<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 colspan=2 style='width:17.1pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:5.0pt;
                                                                                    mso-bidi-font-size:8.0pt;font-family:"Times New Roman"'>pi<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 colspan=2 style='width:17.05pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:5.0pt;
                                                                                    mso-bidi-font-size:8.0pt;font-family:"Times New Roman"'>px<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 colspan=2 style='width:17.1pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:5.0pt;
                                                                                    mso-bidi-font-size:8.0pt;font-family:"Times New Roman"'>ra<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 colspan=2 style='width:17.05pt;border:solid windowtext 1.0pt;
                                                                            border-left:none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:
                                                                            exactly'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:5.0pt;
                                                                                    mso-bidi-font-size:8.0pt;font-family:"Times New Roman"'>rp<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 style='width:17.1pt;border:solid windowtext 1.0pt;border-left:
                                                                            none;mso-border-left-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt;height:11.35pt;mso-height-rule:exactly'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:5.0pt;
                                                                                    mso-bidi-font-size:8.0pt;font-family:"Times New Roman"'>tb<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=23 style='width:17.1pt;border-top:solid windowtext 1.0pt;
                                                                            border-left:none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.5pt;
                                                                            mso-border-left-alt:solid windowtext .5pt;mso-border-alt:solid windowtext .5pt;
                                                                            mso-border-right-alt:solid windowtext 1.5pt;background:white;padding:0cm 5.4pt 0cm 5.4pt;
                                                                            height:11.35pt;mso-height-rule:exactly'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:5.0pt;
                                                                                    mso-bidi-font-size:8.0pt;font-family:"Times New Roman"'>od<o:p></o:p></span></p>
                                                                        </td>
                                                                    </tr>
                                                                    <tr style='mso-yfti-irow:1;height:20.25pt'>
                                                                        <td width=660 colspan=60 style='width:495.25pt;border-top:none;border-left:
                                                                            none;border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.5pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
                                                                            mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext 1.5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt;height:20.25pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:9.0pt'>(*) od: Necess&aacute;rio um
                                                                                    coment&aacute;rio.<o:p></o:p></span></p>
                                                                        </td>
                                                                    </tr>
                                                                    <tr style='mso-yfti-irow:2;height:19.4pt'>
                                                                        <td width=37 colspan=2 valign=top style='width:27.55pt;border-top:none;
                                                                            border-left:solid windowtext 1.5pt;border-bottom:solid windowtext 1.0pt;
                                                                            border-right:solid windowtext 1.0pt;mso-border-top-alt:solid windowtext .5pt;
                                                                            mso-border-alt:solid windowtext .5pt;mso-border-left-alt:solid windowtext 1.5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt;height:19.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'>4C<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=103 colspan=8 rowspan=2 style='width:77.1pt;border:none;border-bottom:
                                                                            solid windowtext 1.5pt;mso-border-top-alt:solid windowtext .5pt;mso-border-left-alt:
                                                                            solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:19.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'>COMENT&Aacute;RIOS:<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=558 colspan=52 rowspan=2 style='width:418.15pt;border-top:none;
                                                                            border-left:none;border-bottom:solid windowtext 1.5pt;border-right:solid windowtext 1.5pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
                                                                            height:19.4pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt;text-transform:uppercase'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                    </tr>
                                                                    <tr style='mso-yfti-irow:3;height:25.1pt'>
                                                                        <td width=37 colspan=2 valign=top style='width:27.55pt;border-top:none;
                                                                            border-left:solid windowtext 1.5pt;border-bottom:solid windowtext 1.5pt;
                                                                            border-right:none;mso-border-top-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
                                                                            height:25.1pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                    </tr>
                                                                    <tr style='mso-yfti-irow:4;height:5.65pt;mso-height-rule:exactly'>
                                                                        <td width=697 colspan=62 valign=top style='width:522.8pt;border:none;
                                                                            border-bottom:solid windowtext 1.0pt;mso-border-top-alt:solid windowtext 1.5pt;
                                                                            mso-border-top-alt:solid windowtext 1.5pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt;height:5.65pt;mso-height-rule:exactly'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:10.0pt'><o:p>&nbsp;</o:p></span></p>
                                                                        </td>
                                                                    </tr>
                                                                    <tr style='mso-yfti-irow:5;height:14.75pt'>
                                                                        <td width=185 colspan=15 valign=top style='width:139.05pt;border-top:none;
                                                                            border-left:solid windowtext 1.0pt;border-bottom:none;border-right:solid windowtext 1.0pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
                                                                            mso-border-left-alt:solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt;height:14.75pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt;text-transform:
                                                                                    uppercase'>DATA:<o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=77 colspan=8 rowspan=2 valign=top style='width:57.75pt;border:none;
                                                                            border-bottom:solid windowtext 1.0pt;mso-border-top-alt:solid windowtext .5pt;
                                                                            mso-border-left-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
                                                                            mso-border-left-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                            padding:0cm 5.4pt 0cm 5.4pt;height:14.75pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><span style='font-size:8.0pt;mso-bidi-font-size:10.0pt'>ASSINATURA:</span><span
                                                                                    style='font-size:10.0pt'><o:p></o:p></span></p>
                                                                        </td>
                                                                        <td width=435 colspan=39 rowspan=2 valign=top style='width:326.0pt;
                                                                            border-top:none;border-left:none;border-bottom:solid windowtext 1.0pt;
                                                                            border-right:solid windowtext 1.0pt;mso-border-top-alt:solid windowtext .5pt;
                                                                            mso-border-top-alt:solid windowtext .5pt;mso-border-bottom-alt:solid windowtext .5pt;
                                                                            mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
                                                                            height:14.75pt'>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><b style='mso-bidi-font-weight:normal'><span
                                                                                        style='font-size:6.0pt;mso-bidi-font-size:8.0pt'><o:p>&nbsp;</o:p></span></b></p>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><b style='mso-bidi-font-weight:normal'><span
                                                                                        style='font-size:7.0pt;mso-bidi-font-size:8.0pt'>Dr. Afranio Pereira<o:p></o:p></span></b></p>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:7.0pt;
                                                                                    mso-bidi-font-size:8.0pt'>Radiologista &#8211; Leitor qualificado
                                                                                    Padr&atilde;o OIT<o:p></o:p></span></p>
                                                                            <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                                                               text-align:center;line-height:normal'><span style='font-size:7.0pt;
                                                                                    mso-bidi-font-size:8.0pt'>CRM 1349 &#8211; CPF 031.695.963-9 &#8211; CBR 3010</span><span
                                                                                    style='font-size:10.0pt'><o:p></o:p></span></p>
                                                                        </td>
                                                                    </tr>
                                                                    <tr style='mso-yfti-irow:6;mso-yfti-lastrow:yes;height:14.7pt'>
                                                                        <td width=185 colspan=15 style='width:139.05pt;border:solid windowtext 1.0pt;
                                                                            border-top:none;mso-border-left-alt:solid windowtext .5pt;mso-border-bottom-alt:
                                                                            solid windowtext .5pt;mso-border-right-alt:solid windowtext .5pt;padding:
                                                                            0cm 5.4pt 0cm 5.4pt;height:14.7pt'>
                                                                            <p class=MsoNormal style='margin-bottom:0cm;margin-bottom:.0001pt;line-height:
                                                                               normal'><b style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;
                                                                                                                           text-transform:uppercase'><o:p>&nbsp;</o:p></span></b></p>
                                                                        </td>
                                                                    </tr>
                                                                    <![if !supportMisalignedColumns]>
                                                                    <tr height=0>
                                                                        <td width=35 style='border:none'></td>
                                                                        <td width=2 style='border:none'></td>
                                                                        <td width=15 style='border:none'></td>
                                                                        <td width=7 style='border:none'></td>
                                                                        <td width=23 style='border:none'></td>
                                                                        <td width=2 style='border:none'></td>
                                                                        <td width=21 style='border:none'></td>
                                                                        <td width=11 style='border:none'></td>
                                                                        <td width=12 style='border:none'></td>
                                                                        <td width=12 style='border:none'></td>
                                                                        <td width=8 style='border:none'></td>
                                                                        <td width=3 style='border:none'></td>
                                                                        <td width=23 style='border:none'></td>
                                                                        <td width=3 style='border:none'></td>
                                                                        <td width=9 style='border:none'></td>
                                                                        <td width=11 style='border:none'></td>
                                                                        <td width=18 style='border:none'></td>
                                                                        <td width=3 style='border:none'></td>
                                                                        <td width=2 style='border:none'></td>
                                                                        <td width=14 style='border:none'></td>
                                                                        <td width=9 style='border:none'></td>
                                                                        <td width=10 style='border:none'></td>
                                                                        <td width=10 style='border:none'></td>
                                                                        <td width=2 style='border:none'></td>
                                                                        <td width=23 style='border:none'></td>
                                                                        <td width=3 style='border:none'></td>
                                                                        <td width=19 style='border:none'></td>
                                                                        <td width=1 style='border:none'></td>
                                                                        <td width=18 style='border:none'></td>
                                                                        <td width=4 style='border:none'></td>
                                                                        <td width=14 style='border:none'></td>
                                                                        <td width=8 style='border:none'></td>
                                                                        <td width=11 style='border:none'></td>
                                                                        <td width=12 style='border:none'></td>
                                                                        <td width=16 style='border:none'></td>
                                                                        <td width=7 style='border:none'></td>
                                                                        <td width=12 style='border:none'></td>
                                                                        <td width=1 style='border:none'></td>
                                                                        <td width=10 style='border:none'></td>
                                                                        <td width=8 style='border:none'></td>
                                                                        <td width=0 style='border:none'></td>
                                                                        <td width=14 style='border:none'></td>
                                                                        <td width=5 style='border:none'></td>
                                                                        <td width=18 style='border:none'></td>
                                                                        <td width=20 style='border:none'></td>
                                                                        <td width=3 style='border:none'></td>
                                                                        <td width=16 style='border:none'></td>
                                                                        <td width=7 style='border:none'></td>
                                                                        <td width=12 style='border:none'></td>
                                                                        <td width=11 style='border:none'></td>
                                                                        <td width=8 style='border:none'></td>
                                                                        <td width=15 style='border:none'></td>
                                                                        <td width=17 style='border:none'></td>
                                                                        <td width=6 style='border:none'></td>
                                                                        <td width=19 style='border:none'></td>
                                                                        <td width=3 style='border:none'></td>
                                                                        <td width=20 style='border:none'></td>
                                                                        <td width=3 style='border:none'></td>
                                                                        <td width=21 style='border:none'></td>
                                                                        <td width=2 style='border:none'></td>
                                                                        <td width=23 style='border:none'></td>
                                                                        <td width=23 style='border:none'></td>
                                                                    </tr>
                                                                    <![endif]>
                                                                </table>

                                                                <p class=MsoNormal><span style='mso-bidi-font-size:10.0pt;line-height:115%'><o:p>&nbsp;</o:p></span></p>

                                                                </div>

                                                                </body>

                                                                </html>
