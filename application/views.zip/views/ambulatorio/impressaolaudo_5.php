<link href="<?= base_url() ?>css/style_p.css" rel="stylesheet" type="text/css" />

<BODY>
    <p><?= $laudo['0']->texto; ?></p>





                                            </BODY>
                                            </HTML>
